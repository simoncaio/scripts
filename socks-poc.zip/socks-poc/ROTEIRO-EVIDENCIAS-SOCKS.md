# Roteiro de Evidencias - POC Cisco Secure Access (Tunel SOCKS)

## Requisito
> Demonstre a capacidade da solucao em identificar e bloquear trafego utilizando
> tunel SOCKS, evidenciando o metodo de deteccao e os logs gerados.

## Dados da Execucao

| Campo                  | Valor                              |
|------------------------|------------------------------------|
| Data/Hora              | ____/____/2026 ___:___             |
| Maquina de teste       | __________________________________ |
| IP da maquina          | __________________________________ |
| Agente Secure Access   | Versao: __________________________ |
| Politica aplicada      | __________________________________ |
| Executor               | __________________________________ |

---

## Descricao do Teste

Realizamos testes de deteccao e bloqueio de tuneis SOCKS originados de uma
estacao Windows integrada ao Cisco Secure Access. O script de teste implementa
o handshake SOCKS5 (RFC 1928) manualmente via conexao TCP raw, enviando os
bytes de greeting (0x05 0x01 0x00) e CONNECT request para proxies SOCKS
publicos em portas padrao (1080, 4145) e porta Tor (9050), alem de um cenario
combinado que tenta estabelecer tunel SOCKS para dominio classificado como
malicioso. Em cada caso, registramos a fase em que ocorreu o bloqueio
(conexao TCP, greeting SOCKS ou CONNECT request), o metodo de deteccao
utilizado pelo Secure Access e a acao aplicada, correlacionando com os logs
da plataforma.

---

## Matriz de Testes

### Teste 1 - SOCKS5-1 (Handshake SOCKS5 porta 1080)

| Item                         | Valor                              |
|------------------------------|------------------------------------|
| Proxy SOCKS                  | 51.79.52.80:1080                   |
| Destino via tunel            | www.google.com:80                  |
| Protocolo                    | SOCKS5 (RFC 1928)                  |
| Resultado esperado           | BLOQUEIO                           |
| Resultado obtido             | [ ] BLOQUEADO  [ ] TIMEOUT  [ ] PERMITIDO |
| Fase em que foi bloqueado    | [ ] TCP connect  [ ] SOCKS greeting  [ ] SOCKS CONNECT  [ ] DNS |
| Metodo de deteccao           | [ ] Assinatura protocolo  [ ] Porta/IP bloqueado  [ ] Politica tunel |
| Evento no Secure Access?     | [ ] Sim (block)  [ ] Nao           |
| Categoria identificada       | __________________________________ |
| Acao aplicada                | __________________________________ |
| Print do cliente             | (anexar)                           |
| Print do log Secure Access   | (anexar)                           |
| Observacoes                  |                                    |

### Teste 2 - SOCKS5-2 (Handshake SOCKS5 porta alternativa)

| Item                         | Valor                              |
|------------------------------|------------------------------------|
| Proxy SOCKS                  | 72.206.181.105:4145                |
| Destino via tunel            | www.google.com:80                  |
| Protocolo                    | SOCKS5 (RFC 1928)                  |
| Resultado esperado           | BLOQUEIO                           |
| Resultado obtido             | [ ] BLOQUEADO  [ ] TIMEOUT  [ ] PERMITIDO |
| Fase em que foi bloqueado    | [ ] TCP connect  [ ] SOCKS greeting  [ ] SOCKS CONNECT  [ ] DNS |
| Metodo de deteccao           | [ ] Assinatura protocolo  [ ] Porta/IP bloqueado  [ ] Politica tunel |
| Evento no Secure Access?     | [ ] Sim (block)  [ ] Nao           |
| Categoria identificada       | __________________________________ |
| Acao aplicada                | __________________________________ |
| Print do cliente             | (anexar)                           |
| Print do log Secure Access   | (anexar)                           |
| Observacoes                  |                                    |

### Teste 3 - SOCKS-TOR (Porta 9050 - Tor SOCKS)

| Item                         | Valor                              |
|------------------------------|------------------------------------|
| Host/Porta                   | 176.10.99.200:9050                 |
| Destino via tunel            | check.torproject.org:80            |
| Protocolo                    | SOCKS5 via Tor                     |
| Resultado esperado           | BLOQUEIO                           |
| Resultado obtido             | [ ] BLOQUEADO  [ ] TIMEOUT  [ ] PERMITIDO |
| Fase em que foi bloqueado    | [ ] TCP connect  [ ] SOCKS greeting  [ ] SOCKS CONNECT  [ ] DNS |
| Metodo de deteccao           | [ ] Assinatura protocolo  [ ] Bloqueio Tor  [ ] Politica tunel |
| Evento no Secure Access?     | [ ] Sim (block)  [ ] Nao           |
| Categoria identificada       | __________________________________ |
| Acao aplicada                | __________________________________ |
| Print do cliente             | (anexar)                           |
| Print do log Secure Access   | (anexar)                           |
| Observacoes                  |                                    |

### Teste 4 - SOCKS5-MAL (Tunel SOCKS para dominio malicioso)

| Item                         | Valor                              |
|------------------------------|------------------------------------|
| Proxy SOCKS                  | 51.79.52.80:1080                   |
| Destino via tunel            | examplemalwaredomain.com:443       |
| Protocolo                    | SOCKS5 (RFC 1928)                  |
| Resultado esperado           | BLOQUEIO                           |
| Resultado obtido             | [ ] BLOQUEADO  [ ] TIMEOUT  [ ] PERMITIDO |
| Fase em que foi bloqueado    | [ ] TCP connect  [ ] SOCKS greeting  [ ] SOCKS CONNECT  [ ] DNS |
| Metodo de deteccao           | [ ] Assinatura protocolo  [ ] Dominio malicioso  [ ] Ambos |
| Evento no Secure Access?     | [ ] Sim (block)  [ ] Nao           |
| Categoria identificada       | __________________________________ |
| Acao aplicada                | __________________________________ |
| Print do cliente             | (anexar)                           |
| Print do log Secure Access   | (anexar)                           |
| Observacoes                  |                                    |

---

## Resumo de Resultados

| Teste        | Esperado   | Obtido     | Conforme? |
|--------------|------------|------------|-----------|
| SOCKS5-1     | BLOQUEIO   |            | [ ] Sim [ ] Nao |
| SOCKS5-2     | BLOQUEIO   |            | [ ] Sim [ ] Nao |
| SOCKS-TOR    | BLOQUEIO   |            | [ ] Sim [ ] Nao |
| SOCKS5-MAL   | BLOQUEIO   |            | [ ] Sim [ ] Nao |

---

## Metodos de Deteccao Observados

Marque quais metodos o Secure Access utilizou para detectar/bloquear SOCKS:

- [ ] **Assinatura de protocolo**: detectou bytes do handshake SOCKS5 (0x05 0x01...)
- [ ] **Categoria de proxy/anonimizador**: classificou destino como proxy/anonymizer
- [ ] **Bloqueio de porta**: porta 1080/9050/4145 bloqueada por politica
- [ ] **Bloqueio de IP/reputacao**: IP do proxy categorizado como risco
- [ ] **Bloqueio de Tor**: categoria especifica para trafego Tor
- [ ] **Inspecao de payload**: conteudo do tunel inspecionado apos deteccao
- [ ] **Outro**: __________________________________________

---

## Criterios de Aceite

O requisito e considerado **ATENDIDO** quando:

1. [  ] Tentativa de tunel SOCKS5 e DETECTADA pelo Secure Access
2. [  ] Conexao SOCKS e BLOQUEADA (reset, drop, deny ou timeout)
3. [  ] Logs do Secure Access registram o evento com:
   - Identificacao do usuario/dispositivo
   - IP/porta de destino (proxy SOCKS)
   - Metodo de deteccao (assinatura, categoria, etc.)
   - Acao aplicada (block/deny/terminate)
4. [  ] Tentativa de tunel SOCKS para Tor e bloqueada
5. [  ] Tunel SOCKS para dominio malicioso e bloqueado

**Veredicto final:** [ ] ATENDIDO  [ ] NAO ATENDIDO  [ ] PARCIAL

---

## Evidencias Anexas

| # | Descricao                                  | Arquivo/Print |
|---|--------------------------------------------|---------------|
| 1 | Saida do cliente (terminal)                |               |
| 2 | Log Secure Access - bloqueio SOCKS5        |               |
| 3 | Log Secure Access - bloqueio Tor           |               |
| 4 | Log Secure Access - bloqueio SOCKS+malware |               |
| 5 | Detalhes do metodo de deteccao             |               |

---

## Observacoes Gerais

(espaco para anotacoes do executor)
