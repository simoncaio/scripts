# Roteiro de Evidencias - POC Cisco Secure Access (Tunel SOCKS)

## Requisito
> Demonstre a capacidade da solucao em identificar e bloquear trafego utilizando
> tunel SOCKS, evidenciando o metodo de deteccao e os logs gerados.

## Dados da Execucao

| Campo                  | Valor                              |
|------------------------|------------------------------------|
| Data/Hora              | ____/____/2026 ___:___             |
| Maquina de teste       | __________________________________ |
| IP da maquina          | __________________________________ |
| Agente Secure Access   | Versao: __________________________ |
| Politica aplicada      | __________________________________ |
| Executor               | __________________________________ |
| Proxies configurados   | SOCKS_PROXY_1080= ________________ |
|                        | SOCKS_PROXY_4145= ________________ |
|                        | SOCKS_PROXY_9050= ________________ |

---

## Descricao do Teste

Realizamos testes de deteccao e bloqueio de tuneis SOCKS originados de uma
estacao Windows integrada ao Cisco Secure Access. O script de teste implementa
o handshake SOCKS5 (RFC 1928) manualmente via conexao TCP raw, enviando os
bytes de greeting (0x05 0x01 0x00) e CONNECT request para proxies SOCKS
em portas padrao (1080, 4145) e porta Tor (9050), alem de um cenario
combinado que tenta estabelecer tunel SOCKS para dominio classificado como
malicioso. Em cada caso, registramos a fase em que ocorreu o bloqueio
(conexao TCP, greeting SOCKS ou CONNECT request), os bytes SOCKS enviados,
o timestamp de inicio (para correlacao com logs CSA), o metodo de deteccao
utilizado pelo Secure Access e a acao aplicada.

---

## Teste 0 - CONTROL-HTTPS (Baseline)

| Item                         | Valor                              |
|------------------------------|------------------------------------|
| Destino                      | www.google.com:443                 |
| Resultado esperado           | Conexao TCP OK                     |
| Resultado obtido             | [ ] OK  [ ] FALHOU                 |
| Timestamp inicio             | __________________________________ |
| Observacoes                  | Valida rede/agente antes dos testes SOCKS |

---

## Matriz de Testes

### Teste 1 - SOCKS5-1 (Handshake SOCKS5 porta 1080)

| Item                         | Valor                              |
|------------------------------|------------------------------------|
| Proxy SOCKS                  | __________________________________ |
| Destino via tunel            | www.google.com:80                  |
| Protocolo                    | SOCKS5 (RFC 1928)                  |
| Timestamp inicio             | __________________________________ |
| Resultado esperado           | BLOQUEIO                           |
| Resultado obtido             | [ ] BLOQUEADO  [ ] TIMEOUT  [ ] PERMITIDO  [ ] PROXY_INACESSIVEL |
| Fase em que foi bloqueado    | [ ] tcp_connect  [ ] socks_greeting  [ ] socks_connect  [ ] complete |
| Bytes SOCKS enviados         | __________________________________ |
| Evidencia valida?            | [ ] Sim (bytes > 0)  [ ] Nao       |
| Metodo de deteccao           | [ ] Assinatura protocolo  [ ] Porta/IP bloqueado  [ ] Politica tunel |
| Evento no Secure Access?     | [ ] Sim (block)  [ ] Nao           |
| Categoria identificada       | __________________________________ |
| Acao aplicada                | __________________________________ |
| Print do cliente             | (anexar)                           |
| Print do log Secure Access   | (anexar)                           |
| Observacoes                  |                                    |

### Teste 2 - SOCKS5-2 (Handshake SOCKS5 porta alternativa)

| Item                         | Valor                              |
|------------------------------|------------------------------------|
| Proxy SOCKS                  | __________________________________ |
| Destino via tunel            | www.google.com:80                  |
| Protocolo                    | SOCKS5 (RFC 1928)                  |
| Timestamp inicio             | __________________________________ |
| Resultado esperado           | BLOQUEIO                           |
| Resultado obtido             | [ ] BLOQUEADO  [ ] TIMEOUT  [ ] PERMITIDO  [ ] PROXY_INACESSIVEL |
| Fase em que foi bloqueado    | [ ] tcp_connect  [ ] socks_greeting  [ ] socks_connect  [ ] complete |
| Bytes SOCKS enviados         | __________________________________ |
| Evidencia valida?            | [ ] Sim (bytes > 0)  [ ] Nao       |
| Metodo de deteccao           | [ ] Assinatura protocolo  [ ] Porta/IP bloqueado  [ ] Politica tunel |
| Evento no Secure Access?     | [ ] Sim (block)  [ ] Nao           |
| Categoria identificada       | __________________________________ |
| Acao aplicada                | __________________________________ |
| Print do cliente             | (anexar)                           |
| Print do log Secure Access   | (anexar)                           |
| Observacoes                  |                                    |

### Teste 3 - SOCKS-TOR (Porta 9050 - Tor SOCKS)

| Item                         | Valor                              |
|------------------------------|------------------------------------|
| Host/Porta                   | __________________________________ |
| Destino via tunel            | check.torproject.org:80            |
| Protocolo                    | SOCKS5 via Tor                     |
| Timestamp inicio             | __________________________________ |
| Resultado esperado           | BLOQUEIO                           |
| Resultado obtido             | [ ] BLOQUEADO  [ ] TIMEOUT  [ ] PERMITIDO  [ ] PROXY_INACESSIVEL |
| Fase em que foi bloqueado    | [ ] tcp_connect  [ ] socks_greeting  [ ] socks_connect  [ ] complete |
| Bytes SOCKS enviados         | __________________________________ |
| Evidencia valida?            | [ ] Sim (bytes > 0)  [ ] Nao       |
| Metodo de deteccao           | [ ] Assinatura protocolo  [ ] Bloqueio Tor  [ ] Politica tunel |
| Evento no Secure Access?     | [ ] Sim (block)  [ ] Nao           |
| Categoria identificada       | __________________________________ |
| Acao aplicada                | __________________________________ |
| Print do cliente             | (anexar)                           |
| Print do log Secure Access   | (anexar)                           |
| Observacoes                  |                                    |

### Teste 4 - SOCKS5-MAL (Tunel SOCKS para dominio malicioso)

| Item                         | Valor                              |
|------------------------------|------------------------------------|
| Proxy SOCKS                  | __________________________________ |
| Destino via tunel            | examplemalwaredomain.com:443       |
| Protocolo                    | SOCKS5 (RFC 1928)                  |
| Timestamp inicio             | __________________________________ |
| Resultado esperado           | BLOQUEIO                           |
| Resultado obtido             | [ ] BLOQUEADO  [ ] TIMEOUT  [ ] PERMITIDO  [ ] PROXY_INACESSIVEL |
| Fase em que foi bloqueado    | [ ] tcp_connect  [ ] socks_greeting  [ ] socks_connect  [ ] complete |
| Bytes SOCKS enviados         | __________________________________ |
| Evidencia valida?            | [ ] Sim (bytes > 0)  [ ] Nao       |
| Metodo de deteccao           | [ ] Assinatura protocolo  [ ] Dominio malicioso  [ ] Ambos |
| Evento no Secure Access?     | [ ] Sim (block)  [ ] Nao           |
| Categoria identificada       | __________________________________ |
| Acao aplicada                | __________________________________ |
| Print do cliente             | (anexar)                           |
| Print do log Secure Access   | (anexar)                           |
| Observacoes                  |                                    |

---

## Resumo de Resultados

| Teste        | Esperado   | Obtido     | Evidencia valida? | Conforme? |
|--------------|------------|------------|-------------------|-----------|
| CONTROL-HTTPS| TCP OK     |            | N/A               | [ ] Sim [ ] Nao |
| SOCKS5-1     | BLOQUEIO   |            | [ ] Sim [ ] Nao   | [ ] Sim [ ] Nao |
| SOCKS5-2     | BLOQUEIO   |            | [ ] Sim [ ] Nao   | [ ] Sim [ ] Nao |
| SOCKS-TOR    | BLOQUEIO   |            | [ ] Sim [ ] Nao   | [ ] Sim [ ] Nao |
| SOCKS5-MAL   | BLOQUEIO   |            | [ ] Sim [ ] Nao   | [ ] Sim [ ] Nao |

---

## Metodos de Deteccao Observados

Marque quais metodos o Secure Access utilizou para detectar/bloquear SOCKS:

- [ ] **Assinatura de protocolo**: detectou bytes do handshake SOCKS5 (0x05 0x01...)
- [ ] **Categoria de proxy/anonimizador**: classificou destino como proxy/anonymizer
- [ ] **Bloqueio de porta**: porta 1080/9050/4145 bloqueada por politica
- [ ] **Bloqueio de IP/reputacao**: IP do proxy categorizado como risco
- [ ] **Bloqueio de Tor**: categoria especifica para trafego Tor
- [ ] **Inspecao de payload**: conteudo do tunel inspecionado apos deteccao
- [ ] **Outro**: __________________________________________

---

## Troubleshooting — Nenhum evento no Secure Access

Se o script mostra TIMEOUT ou PROXY_INACESSIVEL e o CSA nao registra eventos:

1. [ ] Preflight mostrou `TCP_OK` para pelo menos um proxy?
2. [ ] Saida do teste mostra `Bytes SOCKS enviados: 3` ou mais?
3. [ ] `Evidencia valida: SIM` na secao Correlacao CSA?
4. [ ] Proxies configurados via `SOCKS_PROXY_*` foram validados em rede de controle?
5. [ ] Politica SOCKS/anonymizer/Tor esta ativa no Secure Access?
6. [ ] Timestamp do teste foi usado para buscar eventos no console CSA?

Se bytes SOCKS = 0, o CSA **nao tera payload para inspecionar** — o problema e infraestrutura/proxy, nao politica CSA.

---

## Criterios de Aceite

O requisito e considerado **ATENDIDO** quando:

1. [  ] Tentativa de tunel SOCKS5 e DETECTADA pelo Secure Access
2. [  ] Conexao SOCKS e BLOQUEADA (reset, drop, deny ou timeout apos envio de bytes)
3. [  ] Logs do Secure Access registram o evento com:
   - Identificacao do usuario/dispositivo
   - IP/porta de destino (proxy SOCKS)
   - Metodo de deteccao (assinatura, categoria, etc.)
   - Acao aplicada (block/deny/terminate)
4. [  ] Tentativa de tunel SOCKS para Tor e bloqueada
5. [  ] Tunel SOCKS para dominio malicioso e bloqueado
6. [  ] Todos os testes SOCKS com evidencia valida (bytes enviados) foram bloqueados

**Veredicto final:** [ ] ATENDIDO  [ ] NAO ATENDIDO  [ ] PARCIAL

---

## Evidencias Anexas

| # | Descricao                                  | Arquivo/Print |
|---|--------------------------------------------|---------------|
| 0 | Saida preflight + CONTROL-HTTPS            |               |
| 1 | Saida do cliente (terminal)                |               |
| 2 | Log Secure Access - bloqueio SOCKS5        |               |
| 3 | Log Secure Access - bloqueio Tor           |               |
| 4 | Log Secure Access - bloqueio SOCKS+malware |               |
| 5 | Detalhes do metodo de deteccao             |               |
| 6 | Arquivo JSON (RESULTS_JSON), se gerado     |               |

---

## Observacoes Gerais

(espaco para anotacoes do executor)
