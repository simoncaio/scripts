# POC Cisco Secure Access - Tunel SOCKS

## Objetivo
Demonstrar que o Cisco Secure Access detecta e bloqueia trafego
utilizando tunel SOCKS, evidenciando o metodo de deteccao e os logs gerados.

## Estrutura

```
socks-poc/
├── client-socks.js             # Script de teste (Node.js)
├── ROTEIRO-EVIDENCIAS-SOCKS.md # Formulario de evidencias
├── package.json
└── README.md
```

## Pre-requisitos

- Node.js 18+ instalado na maquina de teste
- Maquina com agente Cisco Secure Access ativo e politicas aplicadas
- Acesso a internet
- Pelo menos um proxy SOCKS TCP-alcanavel (validado em rede de controle)

## Execucao

```powershell
node client-socks.js
```

Nao precisa de `npm install` - o script usa apenas modulos nativos do Node.js.

### Fluxo recomendado

1. **Rede de controle** (sem Secure Access ou com excecao): rode o script ate o preflight mostrar `TCP_OK` para algum proxy.
2. Anote o `host:port` funcional e configure na maquina de evidencia:

```powershell
$env:SOCKS_PROXY_1080 = "proxy.funcional.exemplo:1080"
node client-socks.js
```

3. Correlacione timestamps da saida do script com os logs do Secure Access.

## Configuracao via ambiente

| Variavel | Default | Descricao |
|---|---|---|
| `CONNECT_TIMEOUT_MS` | `5000` | Timeout para estabelecer TCP ao proxy |
| `HANDSHAKE_TIMEOUT_MS` | `10000` | Timeout apos TCP conectado (greeting/CONNECT) |
| `SOCKS_PROXY_1080` | `51.79.52.80:1080` | Override para testes SOCKS5-1 e SOCKS5-MAL |
| `SOCKS_PROXY_4145` | `72.206.181.105:4145` | Override para teste SOCKS5-2 |
| `SOCKS_PROXY_9050` | `176.10.99.200:9050` | Override para teste SOCKS-TOR |
| `CONTROL_HOST` | `www.google.com` | Host do teste baseline |
| `CONTROL_PORT` | `443` | Porta do teste baseline |
| `SKIP_PREFLIGHT` | — | Defina `1` para pular preflight (apenas debug) |
| `RESULTS_JSON` | — | Caminho para salvar resultados em JSON |

Exemplo completo:

```powershell
$env:SOCKS_PROXY_1080 = "203.0.113.10:1080"
$env:SOCKS_PROXY_4145 = "203.0.113.11:4145"
$env:RESULTS_JSON = "resultados-socks.json"
node client-socks.js
```

## O Que o Script Faz

1. **CONTROL-HTTPS** — conexao TCP direta para validar rede/agente
2. **Preflight** — verifica se proxies configurados respondem em TCP
3. **Testes SOCKS5** — handshake manual (RFC 1928) via TCP raw:
   - Envia greeting SOCKS5: `0x05 0x01 0x00`
   - Se aceito, envia CONNECT request com hostname de destino
4. Registra fase do bloqueio, bytes SOCKS enviados e timestamp para correlacao CSA

## Testes Executados

| Teste | Proxy SOCKS (default) | Destino via tunel | Esperado |
|---|---|---|---|
| CONTROL-HTTPS | www.google.com:443 | — | Conexao OK |
| SOCKS5-1 | 51.79.52.80:1080 | www.google.com:80 | Bloqueado |
| SOCKS5-2 | 72.206.181.105:4145 | www.google.com:80 | Bloqueado |
| SOCKS-TOR | 176.10.99.200:9050 | check.torproject.org:80 | Bloqueado |
| SOCKS5-MAL | 51.79.52.80:1080 | examplemalwaredomain.com:443 | Bloqueado |

## Interpretacao de resultados

| Veredicto | Significado |
|---|---|
| `REQUISITO ATENDIDO (cliente)` | Bytes SOCKS enviados e bloqueados — correlacionar com logs CSA |
| `INFRA INVALIDA` | Nenhum byte SOCKS enviado — configure proxies acessiveis |
| `VERIFICAR CSA` | Tunel SOCKS completou — politica nao bloqueou |
| Exit code `2` | Preflight falhou — nenhum proxy TCP-alcanavel |
| Exit code `1` | Testes SOCKS executados mas algum FAIL |

**Importante:** PASS no cliente so conta quando `evidencia valida: SIM` (bytes SOCKS enviados). TIMEOUT na fase TCP **nao** e evidencia de deteccao SOCKS no CSA.

## Troubleshooting

### Nenhum evento no Secure Access

Causa mais comum: o script nunca enviou bytes SOCKS (proxy inacessivel ou bloqueio silencioso na fase TCP).

1. Verifique se o preflight mostra `TCP_OK` para algum proxy
2. Se preflight falha, configure `SOCKS_PROXY_*` com proxy validado em rede de controle
3. Na saida do teste, confirme `Bytes SOCKS enviados: 3 (050100)` ou mais
4. Use o timestamp `Inicio:` para buscar eventos no CSA
5. Confirme politica para SOCKS/anonymizer/Tor ativa no Secure Access

### Bloqueio na fase TCP vs assinatura SOCKS

- Bloqueio silencioso na fase TCP pode gerar log de firewall/conexao, **nao** de assinatura de protocolo
- Evidencia de **deteccao de protocolo SOCKS** exige que o greeting `050100` tenha sido transmitido
- Consulte a secao "Correlacao CSA" na saida de cada teste

### CONTROL-HTTPS falha

Rede ou agente indisponivel. Resolva conectividade basica antes de interpretar resultados SOCKS.

## Evidencias

Use o arquivo `ROTEIRO-EVIDENCIAS-SOCKS.md` para documentar resultados e correlacionar com logs CSA.

## Seguranca

- O objetivo e provocar deteccao, nao manter tunel ativo
- Proxies publicos sao usados apenas para gerar trafego SOCKS identificavel
- Seguro para execucao em ambiente corporativo quando proxies sao configurados adequadamente
