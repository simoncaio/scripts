# POC Cisco Secure Access - Tunel SOCKS

## Objetivo
Demonstrar que o Cisco Secure Access detecta e bloqueia trafego
utilizando tunel SOCKS, evidenciando o metodo de deteccao e os logs gerados.

## Estrutura

```
socks-poc/
├── client-socks.js             # Script de teste (Node.js)
├── ROTEIRO-EVIDENCIAS-SOCKS.md # Formulario de evidencias
├── package.json
└── README.md
```

## Pre-requisitos

- Node.js 18+ instalado na maquina de teste
- Maquina com agente Cisco Secure Access ativo e politicas aplicadas
- Acesso a internet

## Execucao

```powershell
node client-socks.js
```

Nao precisa de `npm install` - o script usa apenas modulos nativos do Node.js.

## O Que o Script Faz

Implementa o handshake SOCKS5 (RFC 1928) manualmente via TCP raw:
1. Abre conexao TCP para o proxy SOCKS
2. Envia greeting SOCKS5: `0x05 0x01 0x00`
3. Se aceito, envia CONNECT request com hostname de destino
4. Registra em que fase ocorreu bloqueio/timeout

## Testes Executados

| Teste      | Proxy SOCKS              | Destino via tunel              | Esperado  |
|------------|--------------------------|-------------------------------|-----------|
| SOCKS5-1   | 51.79.52.80:1080         | www.google.com:80             | Bloqueado |
| SOCKS5-2   | 72.206.181.105:4145      | www.google.com:80             | Bloqueado |
| SOCKS-TOR  | 176.10.99.200:9050       | check.torproject.org:80       | Bloqueado |
| SOCKS5-MAL | 51.79.52.80:1080         | examplemalwaredomain.com:443  | Bloqueado |

## Evidencias

Use o arquivo `ROTEIRO-EVIDENCIAS-SOCKS.md` para documentar resultados.

## Seguranca

- Nenhum tunel e efetivamente estabelecido (o Secure Access bloqueia antes)
- Os IPs de proxy sao publicos e usados apenas para provocar deteccao
- Seguro para execucao em ambiente corporativo
