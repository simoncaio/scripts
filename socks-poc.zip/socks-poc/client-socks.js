const net = require("net");
const fs = require("fs");

const CONNECT_TIMEOUT_MS = Number(process.env.CONNECT_TIMEOUT_MS || 5000);
const HANDSHAKE_TIMEOUT_MS = Number(process.env.HANDSHAKE_TIMEOUT_MS || 10000);
const SKIP_PREFLIGHT = process.env.SKIP_PREFLIGHT === "1";
const RESULTS_JSON = process.env.RESULTS_JSON || "";
const CONTROL_HOST = process.env.CONTROL_HOST || "www.google.com";
const CONTROL_PORT = Number(process.env.CONTROL_PORT || 443);

// ---------------------------------------------------------------------------
// Configuracao de proxies via ambiente
// ---------------------------------------------------------------------------

function parseProxyEnv(envName, fallbackHost, fallbackPort) {
  const raw = process.env[envName];
  if (!raw) {
    return { host: fallbackHost, port: fallbackPort };
  }
  const lastColon = raw.lastIndexOf(":");
  if (lastColon <= 0) {
    console.warn(`[AVISO] ${envName}="${raw}" invalido; usando default ${fallbackHost}:${fallbackPort}`);
    return { host: fallbackHost, port: fallbackPort };
  }
  const host = raw.slice(0, lastColon);
  const port = Number(raw.slice(lastColon + 1));
  if (!host || !Number.isFinite(port) || port <= 0) {
    console.warn(`[AVISO] ${envName}="${raw}" invalido; usando default ${fallbackHost}:${fallbackPort}`);
    return { host: fallbackHost, port: fallbackPort };
  }
  return { host, port };
}

function buildTests() {
  const proxy1080 = parseProxyEnv("SOCKS_PROXY_1080", "51.79.52.80", 1080);
  const proxy4145 = parseProxyEnv("SOCKS_PROXY_4145", "72.206.181.105", 4145);
  const proxy9050 = parseProxyEnv("SOCKS_PROXY_9050", "176.10.99.200", 9050);

  return [
    {
      id: "SOCKS5-1",
      label: "Handshake SOCKS5 em porta 1080 (proxy SOCKS padrao)",
      host: proxy1080.host,
      port: proxy1080.port,
      destHost: "www.google.com",
      destPort: 80,
      expectBlock: true
    },
    {
      id: "SOCKS5-2",
      label: "Handshake SOCKS5 em porta 4145 (segundo proxy)",
      host: proxy4145.host,
      port: proxy4145.port,
      destHost: "www.google.com",
      destPort: 80,
      expectBlock: true
    },
    {
      id: "SOCKS-TOR",
      label: "Conexao a porta 9050 (porta padrao Tor SOCKS)",
      host: proxy9050.host,
      port: proxy9050.port,
      destHost: "check.torproject.org",
      destPort: 80,
      expectBlock: true
    },
    {
      id: "SOCKS5-MAL",
      label: "Tunel SOCKS5 para dominio malicioso (examplemalwaredomain.com)",
      host: proxy1080.host,
      port: proxy1080.port,
      destHost: "examplemalwaredomain.com",
      destPort: 443,
      expectBlock: true
    }
  ];
}

const tests = buildTests();
const results = [];

function separator() {
  console.log("=".repeat(72));
}

function isBlockedStatus(status) {
  return status === "BLOQUEADO" || status === "TIMEOUT";
}

function isPassForPoc(result) {
  if (!result.evidenceValid) return false;
  if (!result.expectBlock) return result.status === "PERMITIDO";
  return isBlockedStatus(result.status);
}

function printCsaCorrelation(result) {
  console.log("    --- Correlacao CSA ---");
  console.log(`    Inicio: ${result.startedAt}`);
  console.log(`    Fase bloqueio: ${result.phase}`);
  console.log(`    Bytes SOCKS enviados: ${result.socksBytesSent}${result.payloadsSent.length ? ` (${result.payloadsSent.join(", ")})` : ""}`);
  console.log(`    Proxy destino: ${result.proxy}`);
  console.log(`    Evidencia valida: ${result.evidenceValid ? "SIM" : "NAO"}`);
  if (result.evidenceValid) {
    console.log("    Buscar no CSA: eventos proximos ao timestamp, categoria SOCKS/anonymizer");
  } else {
    console.log("    ATENCAO: nenhum byte SOCKS enviado — CSA provavelmente nao registrara deteccao de protocolo");
  }
}

// ---------------------------------------------------------------------------
// SOCKS5 handshake manual (RFC 1928)
// ---------------------------------------------------------------------------

function buildSocks5Greeting() {
  return Buffer.from([0x05, 0x01, 0x00]);
}

function buildSocks5ConnectRequest(hostname, port) {
  const hostBuf = Buffer.from(hostname, "ascii");
  const buf = Buffer.alloc(4 + 1 + hostBuf.length + 2);
  buf[0] = 0x05;
  buf[1] = 0x01;
  buf[2] = 0x00;
  buf[3] = 0x03;
  buf[4] = hostBuf.length;
  hostBuf.copy(buf, 5);
  buf.writeUInt16BE(port, 5 + hostBuf.length);
  return buf;
}

function tcpConnect(host, port, timeoutMs) {
  return new Promise((resolve) => {
    const start = Date.now();
    const socket = new net.Socket();
    let settled = false;

    const finish = (ok, detail) => {
      if (settled) return;
      settled = true;
      try { socket.destroy(); } catch (_) {}
      resolve({ ok, latencyMs: Date.now() - start, detail });
    };

    const timer = setTimeout(() => {
      finish(false, `timeout apos ${timeoutMs}ms`);
    }, timeoutMs);

    socket.once("connect", () => {
      clearTimeout(timer);
      finish(true, "TCP conectado");
    });

    socket.once("error", (err) => {
      clearTimeout(timer);
      finish(false, err.message);
    });

    socket.connect(port, host);
  });
}

async function runPreflight() {
  separator();
  console.log("PREFLIGHT: verificando conectividade TCP aos proxies configurados");
  console.log(`Timeout de connect: ${CONNECT_TIMEOUT_MS}ms`);
  console.log("");

  const seen = new Set();
  const checks = [];

  for (const test of tests) {
    const key = `${test.host}:${test.port}`;
    if (seen.has(key)) continue;
    seen.add(key);

    process.stdout.write(`  ${key.padEnd(28)} `);
    const result = await tcpConnect(test.host, test.port, CONNECT_TIMEOUT_MS);
    const status = result.ok ? "TCP_OK" : "FALHOU";
    console.log(`${status.padEnd(8)} ${result.latencyMs}ms  ${result.detail}`);
    checks.push({ proxy: key, host: test.host, port: test.port, ...result, status });
  }

  console.log("");
  const reachable = checks.filter((c) => c.ok);
  if (reachable.length === 0) {
    console.error("ERRO: Nenhum proxy TCP-alcanavel. Bytes SOCKS nao serao enviados.");
    console.error("Configure SOCKS_PROXY_1080, SOCKS_PROXY_4145 ou SOCKS_PROXY_9050 com host:port acessiveis.");
    console.error("Valide conectividade em rede de controle antes da maquina com Secure Access.");
    return { ok: false, checks };
  }

  console.log(`${reachable.length}/${checks.length} proxy(s) TCP-alcanavel(is). Prosseguindo com testes SOCKS.`);
  console.log("");
  return { ok: true, checks };
}

function testControlHttps() {
  return new Promise(async (resolve) => {
    separator();
    console.log("[TESTE CONTROL-HTTPS] Baseline de conectividade direta");
    console.log(`[TESTE CONTROL-HTTPS] Destino: ${CONTROL_HOST}:${CONTROL_PORT}`);
    console.log(`[TESTE CONTROL-HTTPS] Esperado: conexao TCP estabelecida (rede/agente ativos)`);
    console.log("");

    const startedAt = new Date().toISOString();
    const start = Date.now();
    const tcp = await tcpConnect(CONTROL_HOST, CONTROL_PORT, CONNECT_TIMEOUT_MS);
    const elapsed = Date.now() - start;

    const status = tcp.ok ? "OK" : "FALHOU";
    const detail = tcp.ok
      ? `Conexao TCP estabelecida em ${tcp.latencyMs}ms`
      : `Falha na conexao: ${tcp.detail}`;

    const result = {
      id: "CONTROL-HTTPS",
      label: "Baseline HTTPS direto",
      target: `${CONTROL_HOST}:${CONTROL_PORT}`,
      proxy: `${CONTROL_HOST}:${CONTROL_PORT}`,
      status,
      detail,
      phase: tcp.ok ? "tcp_connect" : "tcp_connect",
      socksBytesSent: 0,
      payloadsSent: [],
      evidenceValid: false,
      expectBlock: false,
      startedAt,
      elapsedMs: elapsed,
      pass: tcp.ok
    };
    results.push(result);

    console.log(`${tcp.ok ? "[OK]" : "[X]"} Resultado: ${status} (${elapsed}ms)`);
    console.log(`    Detalhe: ${detail}`);
    if (!tcp.ok) {
      console.log("    ATENCAO: rede ou agente pode estar indisponivel — investigar antes dos testes SOCKS");
    }
    console.log("");
    resolve(result);
  });
}

function testSocks5Handshake(test) {
  return new Promise((resolve) => {
    const startedAt = new Date().toISOString();
    const start = Date.now();
    separator();
    console.log(`[TESTE ${test.id}] ${test.label}`);
    console.log(`[TESTE ${test.id}] Proxy: ${test.host}:${test.port}`);
    console.log(`[TESTE ${test.id}] Destino via tunel: ${test.destHost}:${test.destPort}`);
    console.log(`[TESTE ${test.id}] Inicio: ${startedAt}`);
    console.log(`[TESTE ${test.id}] Esperado: BLOQUEIO`);
    console.log("");

    let done = false;
    let phase = "tcp_connect";
    let socksBytesSent = 0;
    const payloadsSent = [];
    let connectTimer = null;
    let handshakeTimer = null;

    const clearTimers = () => {
      if (connectTimer) clearTimeout(connectTimer);
      if (handshakeTimer) clearTimeout(handshakeTimer);
    };

    const writeSocks = (socket, buf, label) => {
      socksBytesSent += buf.length;
      payloadsSent.push(buf.toString("hex"));
      console.log(`[TESTE ${test.id}] ${label}: ${buf.toString("hex")}`);
      socket.write(buf);
    };

    const finish = (status, detail) => {
      if (done) return;
      done = true;
      clearTimers();

      const elapsed = Date.now() - start;
      const evidenceValid = socksBytesSent > 0;
      const pass = evidenceValid && test.expectBlock && isBlockedStatus(status);

      const result = {
        id: test.id,
        label: test.label,
        target: `${test.host}:${test.port} -> ${test.destHost}:${test.destPort}`,
        proxy: `${test.host}:${test.port}`,
        status,
        detail,
        phase,
        socksBytesSent,
        payloadsSent: [...payloadsSent],
        evidenceValid,
        expectBlock: test.expectBlock,
        startedAt,
        elapsedMs: elapsed,
        pass
      };
      results.push(result);

      const icon = pass ? "[OK]" :
        status === "PERMITIDO" ? "[!]" :
        evidenceValid ? "[X]" : "[!]";
      console.log(`${icon} Resultado: ${status} (${elapsed}ms)`);
      console.log(`    Fase final: ${phase}`);
      console.log(`    Detalhe: ${detail}`);
      console.log(`    Conforme esperado: ${pass ? "SIM" : "NAO - VERIFICAR"}`);
      printCsaCorrelation(result);
      console.log("");
      resolve(result);
    };

    const startHandshakeTimer = () => {
      handshakeTimer = setTimeout(() => {
        try { socket.destroy(); } catch (_) {}
        finish("TIMEOUT", `Sem resposta apos envio SOCKS em ${HANDSHAKE_TIMEOUT_MS}ms`);
      }, HANDSHAKE_TIMEOUT_MS);
    };

    const socket = new net.Socket();

    connectTimer = setTimeout(() => {
      try { socket.destroy(); } catch (_) {}
      finish(
        "PROXY_INACESSIVEL",
        `TCP connect nao completou em ${CONNECT_TIMEOUT_MS}ms — nenhum byte SOCKS enviado`
      );
    }, CONNECT_TIMEOUT_MS);

    socket.on("connect", () => {
      clearTimeout(connectTimer);
      phase = "socks_greeting";
      console.log(`[TESTE ${test.id}] TCP conectado, enviando SOCKS5 greeting...`);
      startHandshakeTimer();
      writeSocks(socket, buildSocks5Greeting(), "Payload SOCKS5 greeting");
    });

    socket.on("data", (data) => {
      console.log(`[TESTE ${test.id}] Resposta recebida (${data.length} bytes): ${data.toString("hex")}`);

      if (phase === "socks_greeting") {
        if (data[0] === 0x05 && data[1] === 0x00) {
          phase = "socks_connect";
          console.log(`[TESTE ${test.id}] SOCKS5 greeting aceito (sem auth), enviando CONNECT...`);
          writeSocks(socket, buildSocks5ConnectRequest(test.destHost, test.destPort), "Payload SOCKS5 CONNECT");
        } else if (data[0] === 0x05 && data[1] === 0xFF) {
          clearTimers();
          socket.destroy();
          finish("BLOQUEADO", "Proxy SOCKS5 rejeitou metodos de auth (0xFF)");
        } else {
          clearTimers();
          socket.destroy();
          const ascii = data.toString("utf8").substring(0, 200);
          if (ascii.includes("HTTP") || ascii.includes("block") || ascii.includes("denied")) {
            finish("BLOQUEADO", `Resposta HTTP/block page em vez de SOCKS: ${ascii}`);
          } else {
            finish("BLOQUEADO", `Resposta inesperada (nao-SOCKS): ${data.toString("hex")}`);
          }
        }
      } else if (phase === "socks_connect") {
        clearTimers();
        if (data[0] === 0x05 && data[1] === 0x00) {
          phase = "complete";
          console.log(`[TESTE ${test.id}] SOCKS5 CONNECT bem-sucedido - tunel estabelecido!`);
          socket.destroy();
          finish("PERMITIDO", "Tunel SOCKS5 completo (handshake + CONNECT aceitos)");
        } else {
          socket.destroy();
          const replyCode = data[1];
          const reasons = {
            0x01: "falha geral",
            0x02: "nao permitido por regra",
            0x03: "rede inalcancavel",
            0x04: "host inalcancavel",
            0x05: "conexao recusada",
            0x06: "TTL expirado",
            0x07: "comando nao suportado",
            0x08: "tipo de endereco nao suportado"
          };
          const reason = reasons[replyCode] || `codigo ${replyCode}`;
          finish("BLOQUEADO", `SOCKS5 CONNECT negado: ${reason}`);
        }
      }
    });

    socket.on("error", (err) => {
      clearTimers();
      console.log(`[TESTE ${test.id}] Erro: ${err.message}`);

      if (phase === "tcp_connect") {
        finish("PROXY_INACESSIVEL", `Erro antes de enviar SOCKS: ${err.message}`);
        return;
      }

      const blocked = /ENOTFOUND|ECONNREFUSED|ECONNRESET|ETIMEDOUT|blocked|denied|EPIPE/i.test(err.message);
      finish(blocked ? "BLOQUEADO" : "ERRO", `Erro de conexao: ${err.message}`);
    });

    socket.on("close", () => {
      if (done) return;
      if (socksBytesSent > 0) {
        clearTimers();
        finish("BLOQUEADO", "Conexao resetada/fechada apos envio de bytes SOCKS");
      }
    });

    console.log(`[TESTE ${test.id}] Conectando TCP em ${test.host}:${test.port}...`);
    socket.connect(test.port, test.host);
  });
}

function computeVerdict() {
  const socksResults = results.filter((r) => r.id !== "CONTROL-HTTPS");
  const withEvidence = socksResults.filter((r) => r.evidenceValid);
  const allBlockedWithEvidence = withEvidence.length > 0 &&
    withEvidence.every((r) => r.expectBlock && isBlockedStatus(r.status));
  const anyPermitted = withEvidence.some((r) => r.status === "PERMITIDO");
  const infraInvalid = withEvidence.length === 0;

  if (infraInvalid) {
    return "INFRA INVALIDA — nenhum teste enviou bytes SOCKS; configure proxies acessiveis";
  }
  if (anyPermitted) {
    return "VERIFICAR CSA — bytes SOCKS enviados mas tunel completou (nao bloqueado)";
  }
  if (allBlockedWithEvidence) {
    return "REQUISITO ATENDIDO (cliente) — tuneis SOCKS bloqueados com evidencia valida";
  }
  return "VERIFICAR ITENS MARCADOS COMO FAIL";
}

async function runAll() {
  console.log("");
  console.log("╔══════════════════════════════════════════════════════════════════════╗");
  console.log("║   POC Cisco Secure Access - Teste de Tunel SOCKS                   ║");
  console.log("║   Data: " + new Date().toISOString().padEnd(59) + "║");
  console.log("╚══════════════════════════════════════════════════════════════════════╝");
  console.log("");
  console.log("Protocolo: SOCKS5 (RFC 1928) - handshake manual via TCP raw");
  console.log("O Secure Access deve detectar o protocolo SOCKS no payload e bloquear.");
  console.log(`Connect timeout: ${CONNECT_TIMEOUT_MS}ms | Handshake timeout: ${HANDSHAKE_TIMEOUT_MS}ms`);
  console.log("");

  await testControlHttps();

  if (!SKIP_PREFLIGHT) {
    const preflight = await runPreflight();
    if (!preflight.ok) {
      process.exit(2);
    }
  } else {
    console.log("[AVISO] SKIP_PREFLIGHT=1 — preflight ignorado");
    console.log("");
  }

  for (const test of tests) {
    await testSocks5Handshake(test);
  }

  separator();
  console.log("");
  console.log("╔══════════════════════════════════════════════════════════════════════╗");
  console.log("║                        RESUMO DOS TESTES                            ║");
  console.log("╠══════════════════════════════════════════════════════════════════════╣");

  for (const r of results) {
    const passLabel = r.pass ? "PASS" : "FAIL";
    const evidence = r.evidenceValid ? "evid.ok" : "sem SOCKS";
    const line = `  ${r.id.padEnd(14)} | ${r.status.padEnd(18)} | ${evidence.padEnd(9)} | ${passLabel}`;
    console.log("║" + line.padEnd(70) + "║");
  }

  const verdict = computeVerdict();
  console.log("╠══════════════════════════════════════════════════════════════════════╣");
  console.log("║" + ("  VEREDICTO: " + verdict).padEnd(70) + "║");
  console.log("╚══════════════════════════════════════════════════════════════════════╝");
  console.log("");

  console.log("DETALHES POR TESTE:");
  console.log("");
  for (const r of results) {
    console.log(`  ${r.id}: ${r.status} | fase=${r.phase} | bytes=${r.socksBytesSent} | ${r.detail}`);
  }
  console.log("");

  console.log("CORRELACAO CSA (copiar para o roteiro de evidencias):");
  console.log("");
  for (const r of results.filter((x) => x.id !== "CONTROL-HTTPS")) {
    console.log(`  ${r.id} | ${r.startedAt} | fase=${r.phase} | bytes=${r.socksBytesSent} | evidencia=${r.evidenceValid ? "SIM" : "NAO"}`);
  }
  console.log("");

  if (RESULTS_JSON) {
    const payload = {
      executedAt: new Date().toISOString(),
      config: {
        CONNECT_TIMEOUT_MS,
        HANDSHAKE_TIMEOUT_MS,
        CONTROL_HOST,
        CONTROL_PORT,
        proxies: tests.map((t) => ({ id: t.id, host: t.host, port: t.port }))
      },
      verdict,
      results
    };
    fs.writeFileSync(RESULTS_JSON, JSON.stringify(payload, null, 2), "utf8");
    console.log(`Resultados salvos em: ${RESULTS_JSON}`);
    console.log("");
  }

  const socksResults = results.filter((r) => r.id !== "CONTROL-HTTPS");
  const exitCode = socksResults.some((r) => !r.pass) ? 1 : 0;
  process.exit(exitCode);
}

runAll().catch((err) => {
  console.error("Erro fatal:", err);
  process.exit(1);
});
