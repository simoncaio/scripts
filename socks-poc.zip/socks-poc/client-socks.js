const net = require("net");

const TIMEOUT_MS = Number(process.env.TIMEOUT_MS || 15000);

// ---------------------------------------------------------------------------
// Alvos de teste SOCKS
//
// O Cisco Secure Access deve detectar tentativas de uso de protocolo SOCKS
// (handshake SOCKS4/5 na rede) e/ou bloquear conexoes a proxies SOCKS
// conhecidos, portas comuns (1080, 9050, 4145) e dominios de anonimizacao.
// ---------------------------------------------------------------------------

const tests = [
  {
    id: "SOCKS5-1",
    label: "Handshake SOCKS5 em porta 1080 (proxy SOCKS padrao)",
    host: "51.79.52.80",
    port: 1080,
    destHost: "www.google.com",
    destPort: 80,
    expectBlock: true
  },
  {
    id: "SOCKS5-2",
    label: "Handshake SOCKS5 em porta 4145 (segundo proxy)",
    host: "72.206.181.105",
    port: 4145,
    destHost: "www.google.com",
    destPort: 80,
    expectBlock: true
  },
  {
    id: "SOCKS-TOR",
    label: "Conexao a porta 9050 (porta padrao Tor SOCKS)",
    host: "176.10.99.200",
    port: 9050,
    destHost: "check.torproject.org",
    destPort: 80,
    expectBlock: true
  },
  {
    id: "SOCKS5-MAL",
    label: "Tunel SOCKS5 para dominio malicioso (examplemalwaredomain.com)",
    host: "51.79.52.80",
    port: 1080,
    destHost: "examplemalwaredomain.com",
    destPort: 443,
    expectBlock: true
  }
];

const results = [];

function separator() {
  console.log("=".repeat(72));
}

// ---------------------------------------------------------------------------
// SOCKS5 handshake manual (RFC 1928)
//
// Client greeting:  [0x05, 0x01, 0x00]
//   VER=5, NMETHODS=1, METHOD=0x00 (no auth)
//
// Server response esperada:  [0x05, 0x00]
//   VER=5, METHOD=0x00 (accepted)
//
// Client connect request:
//   [0x05, 0x01, 0x00, 0x03, len, ...hostname, port_hi, port_lo]
//   VER=5, CMD=CONNECT, RSV=0, ATYP=DOMAIN, DST.ADDR, DST.PORT
//
// Se o Secure Access detectar o protocolo SOCKS no payload,
// ele deve bloquear/resetar a conexao antes de completar o handshake.
// ---------------------------------------------------------------------------

function buildSocks5Greeting() {
  return Buffer.from([0x05, 0x01, 0x00]);
}

function buildSocks5ConnectRequest(hostname, port) {
  const hostBuf = Buffer.from(hostname, "ascii");
  const buf = Buffer.alloc(4 + 1 + hostBuf.length + 2);
  buf[0] = 0x05; // VER
  buf[1] = 0x01; // CMD = CONNECT
  buf[2] = 0x00; // RSV
  buf[3] = 0x03; // ATYP = DOMAINNAME
  buf[4] = hostBuf.length;
  hostBuf.copy(buf, 5);
  buf.writeUInt16BE(port, 5 + hostBuf.length);
  return buf;
}

function testSocks5Handshake(test) {
  return new Promise((resolve) => {
    const start = Date.now();
    separator();
    console.log(`[TESTE ${test.id}] ${test.label}`);
    console.log(`[TESTE ${test.id}] Proxy: ${test.host}:${test.port}`);
    console.log(`[TESTE ${test.id}] Destino via tunel: ${test.destHost}:${test.destPort}`);
    console.log(`[TESTE ${test.id}] Esperado: BLOQUEIO`);
    console.log("");

    let done = false;
    const finish = (status, detail) => {
      if (done) return;
      done = true;
      const elapsed = Date.now() - start;
      const result = {
        id: test.id,
        label: test.label,
        target: `${test.host}:${test.port} -> ${test.destHost}:${test.destPort}`,
        status,
        detail,
        elapsedMs: elapsed
      };
      results.push(result);

      const icon = status === "BLOQUEADO" ? "[X]" :
                   status === "PERMITIDO" ? "[!]" :
                   status === "TIMEOUT"   ? "[X]" : "[!]";
      console.log(`${icon} Resultado: ${status} (${elapsed}ms)`);
      console.log(`    Detalhe: ${detail}`);
      const pass = status === "BLOQUEADO" || status === "TIMEOUT";
      console.log(`    Conforme esperado: ${pass ? "SIM" : "NAO - VERIFICAR"}`);
      console.log("");
      resolve(result);
    };

    const socket = new net.Socket();
    socket.setTimeout(TIMEOUT_MS);

    const timer = setTimeout(() => {
      try { socket.destroy(); } catch (_) {}
      finish("TIMEOUT", `Sem resposta em ${TIMEOUT_MS}ms (conexao dropada/bloqueada silenciosamente)`);
    }, TIMEOUT_MS);

    let phase = "connecting";

    socket.on("connect", () => {
      phase = "greeting";
      console.log(`[TESTE ${test.id}] TCP conectado, enviando SOCKS5 greeting...`);
      const greeting = buildSocks5Greeting();
      console.log(`[TESTE ${test.id}] Payload SOCKS5 greeting: ${greeting.toString("hex")}`);
      socket.write(greeting);
    });

    socket.on("data", (data) => {
      console.log(`[TESTE ${test.id}] Resposta recebida (${data.length} bytes): ${data.toString("hex")}`);

      if (phase === "greeting") {
        if (data[0] === 0x05 && data[1] === 0x00) {
          phase = "connect-request";
          console.log(`[TESTE ${test.id}] SOCKS5 greeting aceito (sem auth), enviando CONNECT...`);
          const connectReq = buildSocks5ConnectRequest(test.destHost, test.destPort);
          console.log(`[TESTE ${test.id}] Payload SOCKS5 CONNECT: ${connectReq.toString("hex")}`);
          socket.write(connectReq);
        } else if (data[0] === 0x05 && data[1] === 0xFF) {
          clearTimeout(timer);
          socket.destroy();
          finish("BLOQUEADO", "Proxy SOCKS5 rejeitou metodos de auth (0xFF)");
        } else {
          clearTimeout(timer);
          socket.destroy();
          const ascii = data.toString("utf8").substring(0, 200);
          if (ascii.includes("HTTP") || ascii.includes("block") || ascii.includes("denied")) {
            finish("BLOQUEADO", `Resposta HTTP/block page em vez de SOCKS: ${ascii}`);
          } else {
            finish("BLOQUEADO", `Resposta inesperada (nao-SOCKS): ${data.toString("hex")}`);
          }
        }
      } else if (phase === "connect-request") {
        clearTimeout(timer);
        if (data[0] === 0x05 && data[1] === 0x00) {
          console.log(`[TESTE ${test.id}] SOCKS5 CONNECT bem-sucedido - tunel estabelecido!`);
          socket.destroy();
          finish("PERMITIDO", "Tunel SOCKS5 completo (handshake + CONNECT aceitos)");
        } else {
          socket.destroy();
          const replyCode = data[1];
          const reasons = {
            0x01: "falha geral",
            0x02: "nao permitido por regra",
            0x03: "rede inalcancavel",
            0x04: "host inalcancavel",
            0x05: "conexao recusada",
            0x06: "TTL expirado",
            0x07: "comando nao suportado",
            0x08: "tipo de endereco nao suportado"
          };
          const reason = reasons[replyCode] || `codigo ${replyCode}`;
          finish("BLOQUEADO", `SOCKS5 CONNECT negado: ${reason}`);
        }
      }
    });

    socket.on("error", (err) => {
      clearTimeout(timer);
      console.log(`[TESTE ${test.id}] Erro: ${err.message}`);
      const blocked = /ENOTFOUND|ECONNREFUSED|ECONNRESET|ETIMEDOUT|blocked|denied|EPIPE/i.test(err.message);
      finish(blocked ? "BLOQUEADO" : "ERRO", `Erro de conexao: ${err.message}`);
    });

    socket.on("timeout", () => {
      clearTimeout(timer);
      socket.destroy();
      finish("TIMEOUT", "Socket timeout (bloqueio silencioso)");
    });

    socket.on("close", () => {
      clearTimeout(timer);
    });

    console.log(`[TESTE ${test.id}] Conectando TCP em ${test.host}:${test.port}...`);
    socket.connect(test.port, test.host);
  });
}

async function runAll() {
  console.log("");
  console.log("╔══════════════════════════════════════════════════════════════════════╗");
  console.log("║   POC Cisco Secure Access - Teste de Tunel SOCKS                   ║");
  console.log("║   Data: " + new Date().toISOString().padEnd(59) + "║");
  console.log("╚══════════════════════════════════════════════════════════════════════╝");
  console.log("");
  console.log("Protocolo: SOCKS5 (RFC 1928) - handshake manual via TCP raw");
  console.log("O Secure Access deve detectar o protocolo SOCKS no payload e bloquear.");
  console.log("");

  for (const test of tests) {
    await testSocks5Handshake(test);
  }

  separator();
  console.log("");
  console.log("╔══════════════════════════════════════════════════════════════════════╗");
  console.log("║                        RESUMO DOS TESTES                            ║");
  console.log("╠══════════════════════════════════════════════════════════════════════╣");

  let allPass = true;
  for (const r of results) {
    const pass = r.status === "BLOQUEADO" || r.status === "TIMEOUT";
    if (!pass) allPass = false;
    const line = `  ${r.id.padEnd(14)} | Esperado: BLOQUEIO   | Real: ${r.status.padEnd(10)} | ${pass ? "PASS" : "FAIL"}`;
    console.log("║" + line.padEnd(70) + "║");
  }

  console.log("╠══════════════════════════════════════════════════════════════════════╣");
  const verdict = allPass
    ? "  VEREDICTO: REQUISITO ATENDIDO - Tuneis SOCKS bloqueados"
    : "  VEREDICTO: VERIFICAR ITENS MARCADOS COMO FAIL";
  console.log("║" + verdict.padEnd(70) + "║");
  console.log("╚══════════════════════════════════════════════════════════════════════╝");
  console.log("");

  console.log("DETALHES POR TESTE:");
  console.log("");
  for (const r of results) {
    console.log(`  ${r.id}: ${r.status} | ${r.detail}`);
  }
  console.log("");
}

runAll().catch((err) => {
  console.error("Erro fatal:", err);
  process.exit(1);
});
