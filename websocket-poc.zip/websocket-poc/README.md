# POC Cisco Secure Access - WebSocket + Antimalware/Sandbox

## Objetivo
Demonstrar que o Cisco Secure Access inspeciona, identifica e trata
corretamente trafego WebSocket malicioso.

## Estrutura do Projeto

```
websocket-poc/
├── client-external.js      # Teste via terminal (Node.js) contra alvos externos
├── teste-browser.html      # Teste via browser (abre no Chrome/Edge da maquina)
├── server.js               # Servidor local (usado apenas para testes locais)
├── client.js               # Cliente local (usado apenas para testes locais)
├── ROTEIRO-EVIDENCIAS.md   # Formulario para preencher durante o POC
├── package.json
└── README.md
```

## Pre-requisitos

- Node.js 18+ instalado na maquina de teste
- Maquina com agente Cisco Secure Access ativo e politicas aplicadas
- Acesso a internet (o teste usa dominios externos)

## Instalacao

```powershell
cd "C:\Users\admin\Documents\POC Websocket\websocket-poc\websocket-poc"
npm.cmd install
```

## Como Executar

### Opcao 1: Teste via Terminal (Node.js)

Roda 4 testes sequenciais e exibe matriz de resultados:

```powershell
node client-external.js
```

Testes executados:
- BENIGNO: conexao WebSocket a echo publico (deve ser permitido)
- MALICIOSO-1: WebSocket para examplemalwaredomain.com (deve ser bloqueado)
- MALICIOSO-2: WebSocket para internetbadguys.com (deve ser bloqueado)
- MALICIOSO-3: download EICAR via HTTPS (deve ser bloqueado pelo antimalware)

### Opcao 2: Teste via Browser (recomendado para SWG)

1. Abra o arquivo `teste-browser.html` no Chrome ou Edge da maquina de teste
2. Clique em "Executar Todos os Testes"
3. Aguarde os resultados (cada teste tem timeout de 12s)
4. Tire print da tela com os resultados

O browser usa o proxy/tunel do Secure Access, garantindo que o trafego
seja inspecionado pelo SWG.

## O Que Esperar

### Se o Secure Access esta funcionando corretamente:

- Teste BENIGNO: conexao permitida, resposta recebida
- Testes MALICIOSOS: conexao bloqueada (erro, timeout, reset ou block page)

### Nos logs do Cisco Secure Access:

- Evento para cada tentativa
- Identificacao do dispositivo/usuario
- Dominio de destino
- Classificacao (malware, C2, phishing, etc.)
- Acao aplicada (block/deny)

## Dominios de Teste Usados

| Dominio                       | Proposito                        |
|-------------------------------|----------------------------------|
| echo.websocket.org            | Servico WebSocket publico (safe) |
| examplemalwaredomain.com      | Dominio de teste Cisco (malware) |
| internetbadguys.com           | Dominio de teste Cisco (malware) |
| secure.eicar.org/eicar.com.txt| Arquivo EICAR (teste antimalware)|

## Roteiro de Evidencias

Use o arquivo `ROTEIRO-EVIDENCIAS.md` para documentar os resultados
e anexar prints. Ele contem a matriz Esperado x Observado e os
criterios de aceite do requisito.

## Observacoes de Seguranca

- Nenhum malware real e usado. Os dominios sao de teste da Cisco e da EICAR.
- O arquivo EICAR e um padrao da industria para testar antivirus, NAO e malware.
- Os testes podem ser executados com seguranca em ambiente corporativo.
