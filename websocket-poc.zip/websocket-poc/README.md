# WebSocket Security POC (Cisco Secure Access)

Kit simples para validar inspecao e tratamento de trafego WebSocket.

## Pre-requisitos

- Node.js 18+ instalado
- Maquina cliente passando pelas politicas do Cisco Secure Access

## Estrutura

- `server.js`: servidor WebSocket de laboratorio
- `client.js`: cliente para simular casos benigno/suspeito/malicioso

## Instalacao

No PowerShell, dentro da pasta do projeto:

```powershell
npm install
```

## Execucao

Terminal 1 (servidor):

```powershell
npm run start:server
```

Terminal 2 (cliente benigno):

```powershell
npm run run:client -- benigno
```

Terminal 2 (cliente suspeito):

```powershell
npm run run:client -- suspeito
```

Terminal 2 (cliente malicioso):

```powershell
npm run run:client -- malicioso
```

## Testando com destino remoto

Para apontar para outro endpoint:

```powershell
npm run run:client -- malicioso wss://SEU-ENDPOINT/feed
```

## O que capturar como evidencia

1. Saida do cliente:
   - sucesso (quando permitido)
   - erro/timeout/reset (quando bloqueado)
2. Saida do servidor:
   - conexao aberta, mensagens recebidas ou ausencia de conexao
3. Logs do Cisco Secure Access:
   - usuario/dispositivo
   - dominio/URL/IP
   - classificacao de risco
   - acao aplicada (block/allow/terminate)

## Observacoes de seguranca

- O payload "malicioso" e apenas simulacao com string de teste (EICAR).
- Nao use malware real no POC.
