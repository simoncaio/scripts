# Roteiro de Evidencias - POC Cisco Secure Access (HTML Smuggling)

## Requisito
> Demonstre a capacidade da solucao de extrair e analisar arquivos baixados
> via HTML Smuggling, evidenciando a reconstrucao do arquivo e a deteccao
> da ameaca.

## Dados da Execucao

| Campo                  | Valor                              |
|------------------------|------------------------------------|
| Data/Hora              | ____/____/2026 ___:___             |
| Maquina de teste       | __________________________________ |
| IP da maquina          | __________________________________ |
| Agente Secure Access   | Versao: __________________________ |
| RBI habilitado?        | [ ] Sim  [ ] Nao                   |
| Politica aplicada      | __________________________________ |
| Executor               | __________________________________ |

---

## Descricao do Teste

Foi criada uma pagina HTML que simula a tecnica de HTML Smuggling: JavaScript
embutido reconstroi arquivos maliciosos a partir de fragmentos Base64 ofuscados,
gera um Blob em memoria e dispara download automatico via URL.createObjectURL.
Com Remote Browser Isolation (RBI) habilitado, o Cisco Secure Access executa a
pagina em container remoto e intercepta os arquivos reconstruidos antes de
entrega-los ao endpoint. A pagina foi servida por um servidor HTTP na rede local
para garantir que o trafego passasse pelo proxy/RBI do Secure Access.

---

## Matriz de Testes

### Teste 1 - HTML Smuggling: EICAR Test File

| Item                             | Valor                              |
|----------------------------------|------------------------------------|
| Tecnica                          | Base64 fragmentado (4 partes) + Blob + auto-download |
| Arquivo reconstruido             | eicar-smuggled.com (68 bytes)      |
| Conteudo                         | EICAR-STANDARD-ANTIVIRUS-TEST-FILE |
| Resultado esperado               | BLOQUEIO pelo RBI                  |
| Resultado obtido                 | [ ] BLOQUEADO  [ ] PERMITIDO       |
| Download chegou ao endpoint?     | [ ] Sim  [ ] Nao (bloqueado)       |
| RBI detectou reconstrucao?       | [ ] Sim  [ ] Nao                   |
| Classificacao da ameaca          | __________________________________ |
| Acao aplicada                    | __________________________________ |
| Evento no Secure Access?         | [ ] Sim  [ ] Nao                   |
| Print da pagina (browser)        | (anexar)                           |
| Print do log Secure Access       | (anexar)                           |
| Observacoes                      |                                    |

### Teste 2 - HTML Smuggling: Executavel Simulado (PE header)

| Item                             | Valor                              |
|----------------------------------|------------------------------------|
| Tecnica                          | MZ header + PE stub em Base64 + Blob + auto-download |
| Arquivo reconstruido             | smuggled-payload.exe               |
| Conteudo                         | MZ magic bytes (0x4D5A) + padding  |
| Resultado esperado               | BLOQUEIO pelo RBI                  |
| Resultado obtido                 | [ ] BLOQUEADO  [ ] PERMITIDO       |
| Download chegou ao endpoint?     | [ ] Sim  [ ] Nao (bloqueado)       |
| RBI detectou tipo executavel?    | [ ] Sim  [ ] Nao                   |
| Classificacao da ameaca          | __________________________________ |
| Acao aplicada                    | __________________________________ |
| Evento no Secure Access?         | [ ] Sim  [ ] Nao                   |
| Print da pagina (browser)        | (anexar)                           |
| Print do log Secure Access       | (anexar)                           |
| Observacoes                      |                                    |

### Teste 3 - Controle: Download Direto EICAR (sem smuggling)

| Item                             | Valor                              |
|----------------------------------|------------------------------------|
| Tecnica                          | fetch() direto para URL EICAR      |
| URL                              | https://secure.eicar.org/eicar.com.txt |
| Resultado esperado               | BLOQUEIO pelo antimalware/SWG      |
| Resultado obtido                 | [ ] BLOQUEADO  [ ] PERMITIDO       |
| Tipo de bloqueio                 | [ ] Antimalware  [ ] SWG  [ ] DNS  |
| Evento no Secure Access?         | [ ] Sim  [ ] Nao                   |
| Print da pagina (browser)        | (anexar)                           |
| Print do log Secure Access       | (anexar)                           |
| Observacoes                      |                                    |

---

## Resumo de Resultados

| Teste                  | Esperado   | Obtido     | Conforme? |
|------------------------|------------|------------|-----------|
| Smuggling EICAR        | BLOQUEIO   |            | [ ] Sim [ ] Nao |
| Smuggling PE (.exe)    | BLOQUEIO   |            | [ ] Sim [ ] Nao |
| Download direto EICAR  | BLOQUEIO   |            | [ ] Sim [ ] Nao |

---

## Diferencas entre Smuggling e Download Direto

| Aspecto            | HTML Smuggling                    | Download Direto          |
|--------------------|-----------------------------------|--------------------------|
| Arquivo na rede    | NAO (reconstruido no browser)     | SIM (trafega como HTTP)  |
| Deteccao por SWG   | Dificil (payload e JS/Base64)     | Facil (assinatura direta)|
| Deteccao por RBI   | SIM (intercepta na saida)         | SIM (bloqueio na rede)   |
| Risco real         | Alto (bypassa proxies tradicionais)| Baixo (detectado facilmente) |

---

## Metodos de Deteccao Observados

Marque quais metodos o Secure Access utilizou:

- [ ] **RBI - interceptacao na saida**: arquivo reconstruido detectado no container remoto
- [ ] **Antimalware/sandbox**: EICAR/PE identificado por assinatura
- [ ] **Analise de JavaScript**: padrao de smuggling detectado (Base64 + Blob + download)
- [ ] **Bloqueio de tipo de arquivo**: .exe/.com bloqueado por politica
- [ ] **SWG/Proxy**: bloqueio na camada de rede (download direto)
- [ ] **Outro**: __________________________________________

---

## Criterios de Aceite

O requisito e considerado **ATENDIDO** quando:

1. [  ] Arquivo reconstruido via HTML Smuggling e DETECTADO pelo Secure Access
2. [  ] O RBI intercepta o arquivo antes de entrega-lo ao endpoint
3. [  ] Classificacao da ameaca aparece nos logs (EICAR, malware, suspeito, etc.)
4. [  ] Acao de bloqueio e registrada (block/deny/quarantine)
5. [  ] Download direto de EICAR tambem e bloqueado (controle)
6. [  ] Logs evidenciam a reconstrucao do arquivo (nao apenas bloqueio de URL)

**Veredicto final:** [ ] ATENDIDO  [ ] NAO ATENDIDO  [ ] PARCIAL

---

## Evidencias Anexas

| # | Descricao                                        | Arquivo/Print |
|---|--------------------------------------------------|---------------|
| 1 | Print da pagina HTML (teste smuggling EICAR)     |               |
| 2 | Print da pagina HTML (teste smuggling PE)        |               |
| 3 | Print da pagina HTML (teste download direto)     |               |
| 4 | Log Secure Access - deteccao smuggling EICAR     |               |
| 5 | Log Secure Access - deteccao smuggling PE        |               |
| 6 | Log Secure Access - bloqueio download direto     |               |
| 7 | Sessao RBI registrada                            |               |

---

## Observacoes Gerais

(espaco para anotacoes do executor)
