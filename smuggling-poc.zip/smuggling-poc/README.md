# POC Cisco Secure Access - HTML Smuggling

## Objetivo
Demonstrar que o Cisco Secure Access (com RBI) detecta e bloqueia
arquivos reconstruidos via HTML Smuggling, evidenciando a reconstrucao
do arquivo e a deteccao da ameaca.

## Estrutura

```
smuggling-poc/
├── smuggling-eicar.html            # Pagina HTML com 3 testes de smuggling
├── server.js                       # Servidor HTTP (opcional, para servir via rede)
├── ROTEIRO-EVIDENCIAS-SMUGGLING.md # Formulario de evidencias
└── README.md
```

## Pre-requisitos

- Maquina de teste com Cisco Secure Access + RBI habilitado
- Browser (Chrome/Edge) na maquina de teste
- Node.js (apenas se usar server.js para servir via rede)

## Execucao

### Opcao A: Servir via servidor HTTP (recomendado)

Garante que o trafego passe pelo proxy/RBI do Secure Access:

```powershell
node server.js
```

Acesse no browser da maquina de teste:
```
http://IP-DA-MAQUINA:8080
```

Use o IP da maquina (nao localhost) para garantir que o RBI atue.

### Opcao B: Abrir HTML direto

Se o RBI estiver configurado para interceptar trafego local:
- Copie `smuggling-eicar.html` para a maquina de teste
- Abra no Chrome/Edge

Nota: `file://` pode nao passar pelo proxy. Prefira a Opcao A.

## Testes Disponiveis

### Teste 1 - Fetch-based Smuggling (.exe)
1. JS faz fetch do EICAR de `secure.eicar.org`
2. Aplica XOR para ofuscar os dados em memoria
3. Fragmenta em 4 pedacos
4. Reverte XOR, reconstroi como .exe
5. Dispara download via Blob

O Secure Access pode bloquear no fetch (SWG) ou no download (RBI).

### Teste 2 - Payload XOR Embutido + Chave Remota
1. EICAR esta embutido no HTML cifrado com XOR (indetectavel por analise estatica)
2. JS faz fetch de API publica para simular obtencao da chave
3. Decodifica o payload com a chave XOR
4. Reconstroi como .exe e dispara download via Blob

Analise estatica do HTML NAO revela o EICAR. Apenas o RBI pode detectar.

### Teste 3 - Download Direto (controle)
- Fetch direto de EICAR sem smuggling
- Serve como comparacao: SWG bloqueia facilmente

## Pontos de Deteccao do Secure Access

| Ponto          | Teste 1 | Teste 2 | Teste 3 |
|----------------|---------|---------|---------|
| SWG (fetch)    | Sim     | Nao*    | Sim     |
| RBI (download) | Sim     | Sim     | Sim     |

*O fetch do Teste 2 e para uma API publica benigna (nao contem EICAR).

## Seguranca

- EICAR e padrao da industria para teste antivirus, NAO e malware real
- Os .exe gerados NAO sao executaveis reais (contem apenas a string EICAR)
- Seguros para ambiente corporativo
