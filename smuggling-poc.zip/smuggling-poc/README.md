# POC Cisco Secure Access - HTML Smuggling

## Objetivo
Demonstrar que o Cisco Secure Access (com RBI) detecta e bloqueia
arquivos reconstruidos via HTML Smuggling, evidenciando a reconstrucao
do arquivo e a deteccao da ameaca.

## Estrutura

```
smuggling-poc/
├── smuggling-eicar.html            # Pagina HTML com smuggling (3 testes)
├── server.js                       # Servidor HTTP simples (Node.js nativo)
├── ROTEIRO-EVIDENCIAS-SMUGGLING.md # Formulario de evidencias
└── README.md
```

## Pre-requisitos

- Node.js 18+ na maquina que servira o HTML
- Maquina de teste com Cisco Secure Access + RBI habilitado
- Browser (Chrome/Edge) na maquina de teste

## Execucao

### 1. Subir o servidor HTTP

Na maquina de teste (ou em outra maquina acessivel pela rede):

```powershell
node server.js
```

O servidor inicia na porta 8080.

### 2. Acessar pelo browser da maquina de teste

Abra no Chrome ou Edge:

```
http://IP-DA-MAQUINA:8080
```

IMPORTANTE: use o IP da maquina (nao localhost), para garantir que
o trafego passe pelo proxy/RBI do Secure Access.

### 3. Executar os testes

A pagina tem 3 botoes:
1. "Executar Smuggling EICAR" - reconstroi EICAR via Base64 fragmentado
2. "Executar Smuggling PE" - reconstroi arquivo com MZ header
3. "Executar Download Direto" - controle (fetch direto de EICAR)

### 4. Coletar evidencias

- Print da pagina com logs de cada teste
- Logs do Cisco Secure Access (Activity Search)
- Verificar se o arquivo chegou ao disco (Downloads)

## Como Funciona

### HTML Smuggling (Testes 1 e 2)
O JavaScript embutido na pagina:
1. Decodifica fragmentos Base64 (simulando ofuscacao)
2. Concatena os fragmentos em memoria
3. Cria um Blob (arquivo binario em memoria)
4. Dispara download automatico via URL.createObjectURL

O arquivo malicioso NUNCA trafega pela rede como binario.
E reconstruido inteiramente dentro do browser.

### Por que o RBI detecta
Com Remote Browser Isolation, a pagina executa em container remoto
da Cisco. Quando o JS tenta entregar o arquivo reconstruido ao
endpoint, o RBI intercepta o Blob/download na saida do container
e submete a analise antimalware/sandbox.

### Download Direto (Teste 3)
Fetch HTTP normal para EICAR. Serve como controle para mostrar
que o SWG tambem bloqueia downloads convencionais.

## Seguranca

- O EICAR e padrao da industria para teste antivirus, NAO e malware real
- O PE header simulado NAO e um executavel funcional
- Os testes sao seguros para ambiente corporativo
- Nenhuma dependencia externa (server.js usa modulos nativos do Node.js)
