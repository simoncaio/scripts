# Roteiro de Evidencias - POC Cisco Secure Access (HTML Smuggling)

## Requisito
> Demonstre a capacidade da solucao de extrair e analisar arquivos baixados
> via HTML Smuggling, evidenciando a reconstrucao do arquivo e a deteccao
> da ameaca.

## Dados da Execucao

| Campo                  | Valor                              |
|------------------------|------------------------------------|
| Data/Hora              | ____/____/2026 ___:___             |
| Maquina de teste       | __________________________________ |
| IP da maquina          | __________________________________ |
| Agente Secure Access   | Versao: __________________________ |
| RBI habilitado?        | [ ] Sim  [ ] Nao                   |
| Politica aplicada      | __________________________________ |
| Executor               | __________________________________ |

---

## Descricao do Teste

Foram executados testes de HTML Smuggling a partir de uma estacao Windows
integrada ao Cisco Secure Access com Remote Browser Isolation (RBI) habilitado.
A pagina de teste utiliza a tecnica de fetch-based smuggling e um teste de controle:

1) **Fetch-based smuggling**: JavaScript faz fetch do arquivo EICAR diretamente
   de secure.eicar.org, aplica ofuscacao XOR em memoria, fragmenta os dados,
   reverte a ofuscacao e reconstroi o arquivo como .exe via Blob API com
   download automatico.

Em ambos os cenarios, o Secure Access pode atuar em dois pontos: bloqueio
do fetch na rede (SWG/antimalware) e interceptacao do arquivo reconstruido
na saida do RBI.

---

## Matriz de Testes

### Teste 1 - Fetch-based Smuggling (EICAR como .exe)

| Item                             | Valor                              |
|----------------------------------|------------------------------------|
| Tecnica                          | Fetch de secure.eicar.org + XOR + fragmentacao em memoria + Blob .exe |
| Destino do fetch                 | https://secure.eicar.org/eicar.com |
| Arquivo reconstruido             | eicar-smuggled.exe                 |
| Resultado esperado               | BLOQUEIO (SWG no fetch OU RBI no download) |
| Resultado obtido                 | [ ] BLOQUEADO no fetch  [ ] BLOQUEADO no RBI  [ ] PERMITIDO |
| Ponto de deteccao                | [ ] SWG (fetch bloqueado)  [ ] RBI (Blob interceptado)  [ ] Ambos |
| Download chegou ao endpoint?     | [ ] Sim  [ ] Nao (bloqueado)       |
| Classificacao da ameaca          | __________________________________ |
| Acao aplicada                    | __________________________________ |
| Evento no Secure Access?         | [ ] Sim  [ ] Nao                   |
| Print da pagina (browser)        | (anexar)                           |
| Print do log Secure Access       | (anexar)                           |
| Observacoes                      |                                    |

### Teste 3 - Controle: Download Direto EICAR (sem smuggling)

| Item                             | Valor                              |
|----------------------------------|------------------------------------|
| Tecnica                          | fetch direto (sem ofuscacao/smuggling) |
| URLs testadas                    | eicar.com / eicar.com.txt / eicarcom2.zip |
| Resultado esperado               | BLOQUEIO pelo SWG/Antimalware      |
| Resultado obtido                 | [ ] BLOQUEADO  [ ] PERMITIDO       |
| Tipo de bloqueio                 | [ ] SWG  [ ] Antimalware  [ ] DNS  |
| Evento no Secure Access?         | [ ] Sim  [ ] Nao                   |
| Print da pagina (browser)        | (anexar)                           |
| Print do log Secure Access       | (anexar)                           |
| Observacoes                      |                                    |

---

## Resumo de Resultados

| Teste                       | Esperado   | Obtido     | Conforme? |
|-----------------------------|------------|------------|-----------|
| Fetch-based smuggling .exe  | BLOQUEIO   |            | [ ] Sim [ ] Nao |
| Download direto (controle)  | BLOQUEIO   |            | [ ] Sim [ ] Nao |

---

## Comparacao: Smuggling vs Download Direto

| Aspecto                | Fetch-based Smuggling     | Download Direto       |
|------------------------|---------------------------|-----------------------|
| EICAR visivel na rede? | Sim (no fetch inicial)    | Sim                   |
| Detectavel por SWG?    | Sim (no fetch)            | Sim                   |
| Detectavel por RBI?    | Sim (Blob na saida)       | Sim (rede)            |
| Risco real             | Medio                     | Baixo                 |

---

## Metodos de Deteccao Observados

- [ ] **SWG - bloqueio no fetch**: EICAR detectado no trafego HTTP
- [ ] **RBI - interceptacao do Blob**: arquivo reconstruido detectado na saida do container
- [ ] **Analise de JS**: padrao de smuggling detectado (XOR + Blob + download)
- [ ] **Bloqueio de tipo de arquivo**: .exe bloqueado por politica de download
- [ ] **Antimalware/sandbox**: assinatura EICAR no arquivo reconstruido
- [ ] **Outro**: __________________________________________

---

## Criterios de Aceite

O requisito e considerado **ATENDIDO** quando:

1. [  ] Arquivo reconstruido via smuggling e DETECTADO pelo Secure Access
2. [  ] O RBI intercepta o arquivo antes da entrega ao endpoint
3. [  ] Classificacao da ameaca aparece nos logs (EICAR / malware / suspeito)
4. [  ] Acao de bloqueio registrada (block/deny/quarantine)
5. [  ] Download direto tambem e bloqueado (controle)
6. [  ] Logs evidenciam reconstrucao/deteccao do arquivo (nao apenas bloqueio de URL)

**Veredicto final:** [ ] ATENDIDO  [ ] NAO ATENDIDO  [ ] PARCIAL

---

## Evidencias Anexas

| # | Descricao                                        | Arquivo/Print |
|---|--------------------------------------------------|---------------|
| 1 | Print da pagina - Teste 1 (fetch smuggling)      |               |
| 2 | Print da pagina - Teste 3 (download direto)      |               |
| 3 | Log Secure Access - deteccao smuggling            |               |
| 4 | Log Secure Access - sessao RBI                    |               |
| 5 | Log Secure Access - bloqueio download direto      |               |
| 6 | Pasta Downloads (arquivo chegou ou nao)           |               |

---

## Observacoes Gerais

(espaco para anotacoes do executor)
