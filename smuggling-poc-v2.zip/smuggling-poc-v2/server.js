const http = require("http");
const fs = require("fs");
const path = require("path");

const PORT = Number(process.env.PORT || 8080);
const HOST = process.env.HOST || "0.0.0.0";

const MIME = {
  ".html": "text/html; charset=utf-8",
  ".js":   "application/javascript",
  ".css":  "text/css",
  ".json": "application/json",
  ".png":  "image/png",
  ".ico":  "image/x-icon"
};

const server = http.createServer((req, res) => {
  const ts = new Date().toISOString();
  const ip = req.socket.remoteAddress;
  const ua = req.headers["user-agent"] || "n/a";

  console.log(`[${ts}] ${req.method} ${req.url} ip=${ip} ua="${ua}"`);

  if (req.url === "/" || req.url === "/index.html") {
    req.url = "/smuggling-eicar.html";
  }

  const safePath = path.join(__dirname, path.normalize(req.url).replace(/^(\.\.[\/\\])+/, ""));
  const ext = path.extname(safePath).toLowerCase();

  fs.readFile(safePath, (err, data) => {
    if (err) {
      console.log(`[${ts}] 404 ${safePath}`);
      res.writeHead(404, { "Content-Type": "text/plain" });
      res.end("404 Not Found");
      return;
    }
    res.writeHead(200, {
      "Content-Type": MIME[ext] || "application/octet-stream",
      "Cache-Control": "no-store"
    });
    res.end(data);
  });
});

server.listen(PORT, HOST, () => {
  console.log("");
  console.log("========================================================");
  console.log("  POC HTML Smuggling - Servidor HTTP");
  console.log(`  Ativo em http://${HOST}:${PORT}`);
  console.log("  Acesse pelo browser da maquina de teste.");
  console.log("========================================================");
  console.log("");
  console.log("Importante: acesse usando o IP da maquina (nao localhost)");
  console.log("para garantir que o trafego passe pelo Secure Access/RBI.");
  console.log("");
});

server.on("error", (err) => {
  if (err.code === "EADDRINUSE") {
    console.error(`Porta ${PORT} ja esta em uso. Use: PORT=9090 node server.js`);
  } else {
    console.error("Erro:", err.message);
  }
  process.exit(1);
});
