const WebSocket = require("ws");
const https = require("https");
const http = require("http");

const TIMEOUT_MS = Number(process.env.TIMEOUT_MS || 15000);

// ---------------------------------------------------------------------------
// Alvos de teste
//
// BENIGNO   : servidor WebSocket público de echo (tráfego legítimo)
// MALICIOSO : domínios de teste reconhecidos pela Cisco como maliciosos
//
// O Cisco Secure Access faz inspeção na camada DNS (Umbrella) e no SWG.
// Ao tentar resolver/conectar nesses domínios, o agente deve:
//   - bloquear a resolução DNS, ou
//   - interceptar o handshake HTTP Upgrade e retornar block page, ou
//   - resetar/dropar a conexão.
// ---------------------------------------------------------------------------

const tests = [
  {
    id: "BENIGNO",
    label: "WebSocket echo público (tráfego legítimo)",
    url: "wss://echo.websocket.org",
    payload: JSON.stringify({ msg: "hello-poc", ts: new Date().toISOString() }),
    expectBlock: false
  },
  {
    id: "MALICIOSO-1",
    label: "Domínio de teste Cisco (examplemalwaredomain.com)",
    url: "wss://examplemalwaredomain.com/ws",
    payload: JSON.stringify({ c2: "beacon", ts: new Date().toISOString() }),
    expectBlock: true
  },
  {
    id: "MALICIOSO-2",
    label: "Domínio de teste Cisco (internetbadguys.com)",
    url: "wss://internetbadguys.com/ws",
    payload: JSON.stringify({ c2: "exfil", ts: new Date().toISOString() }),
    expectBlock: true
  },
  {
    id: "MALICIOSO-3",
    label: "URL EICAR via HTTPS (download de malware de teste)",
    url: "HTTPS_TEST",
    httpsUrl: "https://secure.eicar.org/eicar.com.txt",
    payload: null,
    expectBlock: true
  }
];

// ---------------------------------------------------------------------------
// Execução sequencial dos testes
// ---------------------------------------------------------------------------

const results = [];

function separator() {
  console.log("=".repeat(72));
}

function testWebSocket(test) {
  return new Promise((resolve) => {
    const start = Date.now();
    separator();
    console.log(`[TESTE ${test.id}] ${test.label}`);
    console.log(`[TESTE ${test.id}] URL: ${test.url}`);
    console.log(`[TESTE ${test.id}] Esperado: ${test.expectBlock ? "BLOQUEIO" : "PERMITIDO"}`);
    console.log("");

    const ws = new WebSocket(test.url, {
      handshakeTimeout: TIMEOUT_MS,
      rejectUnauthorized: true
    });

    let done = false;
    const finish = (status, detail) => {
      if (done) return;
      done = true;
      const elapsed = Date.now() - start;
      const result = {
        id: test.id,
        label: test.label,
        url: test.url,
        expectBlock: test.expectBlock,
        status,
        detail,
        elapsedMs: elapsed
      };
      results.push(result);

      const icon = status === "BLOQUEADO" ? "[X]" :
                   status === "PERMITIDO" ? "[OK]" :
                   status === "TIMEOUT"   ? "[?]" : "[!]";
      console.log(`${icon} Resultado: ${status} (${elapsed}ms)`);
      console.log(`    Detalhe: ${detail}`);

      const match = (test.expectBlock && status === "BLOQUEADO") ||
                    (!test.expectBlock && status === "PERMITIDO");
      console.log(`    Conforme esperado: ${match ? "SIM" : "NAO - VERIFICAR"}`);
      console.log("");
      resolve(result);
    };

    const timer = setTimeout(() => {
      try { ws.close(); } catch (_) {}
      finish("TIMEOUT", `Sem resposta em ${TIMEOUT_MS}ms (possível drop silencioso)`);
    }, TIMEOUT_MS);

    ws.on("open", () => {
      console.log(`[TESTE ${test.id}] Conexao aberta, enviando payload...`);
      if (test.payload) ws.send(test.payload);
    });

    ws.on("message", (raw) => {
      clearTimeout(timer);
      const msg = raw.toString().substring(0, 300);
      console.log(`[TESTE ${test.id}] Resposta: ${msg}`);
      ws.close(1000);
      finish("PERMITIDO", `Mensagem recebida: ${msg.substring(0, 120)}`);
    });

    ws.on("unexpected-response", (_req, res) => {
      clearTimeout(timer);
      let body = "";
      res.on("data", (chunk) => { body += chunk.toString(); });
      res.on("end", () => {
        const statusLine = `HTTP ${res.statusCode} ${res.statusMessage || ""}`;
        const snippet = body.substring(0, 200);
        console.log(`[TESTE ${test.id}] Resposta HTTP (nao-WebSocket): ${statusLine}`);
        if (snippet) console.log(`[TESTE ${test.id}] Body: ${snippet}`);
        finish("BLOQUEADO", `${statusLine} - ${snippet || "sem body"}`);
      });
    });

    ws.on("error", (err) => {
      clearTimeout(timer);
      const msg = err.message || String(err);
      console.log(`[TESTE ${test.id}] Erro: ${msg}`);
      const blocked = /ENOTFOUND|ECONNREFUSED|ECONNRESET|ETIMEDOUT|certificate|blocked|denied|self.signed/i.test(msg);
      finish(blocked ? "BLOQUEADO" : "ERRO", msg);
    });
  });
}

function testHttpsDownload(test) {
  return new Promise((resolve) => {
    const start = Date.now();
    separator();
    console.log(`[TESTE ${test.id}] ${test.label}`);
    console.log(`[TESTE ${test.id}] URL: ${test.httpsUrl}`);
    console.log(`[TESTE ${test.id}] Esperado: ${test.expectBlock ? "BLOQUEIO" : "PERMITIDO"}`);
    console.log("");

    let done = false;
    const finish = (status, detail) => {
      if (done) return;
      done = true;
      const elapsed = Date.now() - start;
      const result = {
        id: test.id,
        label: test.label,
        url: test.httpsUrl,
        expectBlock: test.expectBlock,
        status,
        detail,
        elapsedMs: elapsed
      };
      results.push(result);
      const icon = status === "BLOQUEADO" ? "[X]" :
                   status === "PERMITIDO" ? "[OK]" :
                   status === "TIMEOUT"   ? "[?]" : "[!]";
      console.log(`${icon} Resultado: ${status} (${elapsed}ms)`);
      console.log(`    Detalhe: ${detail}`);
      const match = (test.expectBlock && status === "BLOQUEADO") ||
                    (!test.expectBlock && status === "PERMITIDO");
      console.log(`    Conforme esperado: ${match ? "SIM" : "NAO - VERIFICAR"}`);
      console.log("");
      resolve(result);
    };

    const timer = setTimeout(() => finish("TIMEOUT", `Sem resposta em ${TIMEOUT_MS}ms`), TIMEOUT_MS);

    const req = https.get(test.httpsUrl, { timeout: TIMEOUT_MS }, (res) => {
      clearTimeout(timer);
      let body = "";
      res.on("data", (chunk) => { body += chunk.toString(); });
      res.on("end", () => {
        const hasEicar = body.includes("EICAR") || body.includes("X5O!P%");
        const statusLine = `HTTP ${res.statusCode}`;
        if (res.statusCode >= 400 || !hasEicar) {
          finish("BLOQUEADO", `${statusLine} - conteudo bloqueado/modificado pelo SWG`);
        } else {
          finish("PERMITIDO", `${statusLine} - EICAR baixado sem bloqueio (${body.length} bytes)`);
        }
      });
    });

    req.on("error", (err) => {
      clearTimeout(timer);
      finish("BLOQUEADO", `Erro de conexao: ${err.message}`);
    });
  });
}

async function runAll() {
  console.log("");
  console.log("╔══════════════════════════════════════════════════════════════════════╗");
  console.log("║   POC Cisco Secure Access - Teste de WebSocket + Malware/Sandbox   ║");
  console.log("║   Data: " + new Date().toISOString().padEnd(59) + "║");
  console.log("╚══════════════════════════════════════════════════════════════════════╝");
  console.log("");

  for (const test of tests) {
    if (test.url === "HTTPS_TEST") {
      await testHttpsDownload(test);
    } else {
      await testWebSocket(test);
    }
  }

  separator();
  console.log("");
  console.log("╔══════════════════════════════════════════════════════════════════════╗");
  console.log("║                        RESUMO DOS TESTES                            ║");
  console.log("╠══════════════════════════════════════════════════════════════════════╣");

  let allPass = true;
  for (const r of results) {
    const match = (r.expectBlock && r.status === "BLOQUEADO") ||
                  (!r.expectBlock && r.status === "PERMITIDO");
    if (!match) allPass = false;
    const line = `  ${r.id.padEnd(14)} | Esperado: ${(r.expectBlock ? "BLOQUEIO" : "PERMITIDO").padEnd(10)} | Real: ${r.status.padEnd(10)} | ${match ? "PASS" : "FAIL"}`;
    console.log("║" + line.padEnd(70) + "║");
  }

  console.log("╠══════════════════════════════════════════════════════════════════════╣");
  const verdict = allPass
    ? "  VEREDICTO: REQUISITO ATENDIDO"
    : "  VEREDICTO: VERIFICAR ITENS MARCADOS COMO FAIL";
  console.log("║" + verdict.padEnd(70) + "║");
  console.log("╚══════════════════════════════════════════════════════════════════════╝");
  console.log("");
}

runAll().catch((err) => {
  console.error("Erro fatal:", err);
  process.exit(1);
});
