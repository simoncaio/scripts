const { WebSocketServer } = require("ws");

const PORT = Number(process.env.PORT || 8080);
const WSS_PATH = process.env.WSS_PATH || "/feed";

const wss = new WebSocketServer({
  port: PORT,
  path: WSS_PATH
});

console.log(`[server] WebSocket lab ativo em ws://localhost:${PORT}${WSS_PATH}`);

wss.on("connection", (ws, req) => {
  const sourceIp = req.socket.remoteAddress;
  const userAgent = req.headers["user-agent"] || "n/a";
  const connectedAt = new Date().toISOString();

  console.log(`[server] conexao aberta ip=${sourceIp} ua="${userAgent}" at=${connectedAt}`);

  ws.send(
    JSON.stringify({
      type: "banner",
      message: "Lab WebSocket conectado",
      ts: connectedAt
    })
  );

  ws.on("message", (raw) => {
    const payload = raw.toString();
    const ts = new Date().toISOString();
    console.log(`[server] msg recebida at=${ts} payload=${payload}`);

    ws.send(
      JSON.stringify({
        type: "ack",
        received: payload,
        ts
      })
    );
  });

  ws.on("close", (code, reasonBuffer) => {
    const reason = reasonBuffer.toString() || "sem motivo";
    console.log(`[server] conexao encerrada code=${code} reason="${reason}"`);
  });

  ws.on("error", (err) => {
    console.error(`[server] erro websocket: ${err.message}`);
  });
});

wss.on("error", (err) => {
  console.error(`[server] erro geral: ${err.message}`);
});
