# POC Cisco Secure Access - WebSocket + SOCKS + Antimalware/Sandbox

## Objetivo
Demonstrar que o Cisco Secure Access inspeciona, identifica e trata
corretamente trafego WebSocket malicioso e tuneis SOCKS.

## Estrutura do Projeto

```
websocket-poc/
├── client-external.js          # Teste WebSocket contra alvos externos
├── client-socks.js             # Teste de tunel SOCKS5 contra proxies externos
├── teste-browser.html          # Teste WebSocket via browser
├── server.js                   # Servidor local (testes locais)
├── client.js                   # Cliente local (testes locais)
├── ROTEIRO-EVIDENCIAS.md       # Formulario de evidencias (WebSocket)
├── ROTEIRO-EVIDENCIAS-SOCKS.md # Formulario de evidencias (SOCKS)
├── package.json
└── README.md
```

## Pre-requisitos

- Node.js 18+ instalado na maquina de teste
- Maquina com agente Cisco Secure Access ativo e politicas aplicadas
- Acesso a internet (o teste usa dominios externos)

## Instalacao

```powershell
cd "C:\Users\admin\Documents\POC Websocket\websocket-poc\websocket-poc"
npm.cmd install
```

## Como Executar

### Opcao 1: Teste via Terminal (Node.js)

Roda 4 testes sequenciais e exibe matriz de resultados:

```powershell
node client-external.js
```

Testes executados:
- BENIGNO: conexao WebSocket a echo publico (deve ser permitido)
- MALICIOSO-1: WebSocket para examplemalwaredomain.com (deve ser bloqueado)
- MALICIOSO-2: WebSocket para internetbadguys.com (deve ser bloqueado)
- MALICIOSO-3: download EICAR via HTTPS (deve ser bloqueado pelo antimalware)

### Opcao 2: Teste via Browser (recomendado para SWG)

1. Abra o arquivo `teste-browser.html` no Chrome ou Edge da maquina de teste
2. Clique em "Executar Todos os Testes"
3. Aguarde os resultados (cada teste tem timeout de 12s)
4. Tire print da tela com os resultados

O browser usa o proxy/tunel do Secure Access, garantindo que o trafego
seja inspecionado pelo SWG.

## O Que Esperar

### Se o Secure Access esta funcionando corretamente:

- Teste BENIGNO: conexao permitida, resposta recebida
- Testes MALICIOSOS: conexao bloqueada (erro, timeout, reset ou block page)

### Nos logs do Cisco Secure Access:

- Evento para cada tentativa
- Identificacao do dispositivo/usuario
- Dominio de destino
- Classificacao (malware, C2, phishing, etc.)
- Acao aplicada (block/deny)

## Dominios de Teste Usados

| Dominio                       | Proposito                        |
|-------------------------------|----------------------------------|
| echo.websocket.org            | Servico WebSocket publico (safe) |
| examplemalwaredomain.com      | Dominio de teste Cisco (malware) |
| internetbadguys.com           | Dominio de teste Cisco (malware) |
| secure.eicar.org/eicar.com.txt| Arquivo EICAR (teste antimalware)|

## Teste de Tunel SOCKS

Roda 5 testes que tentam estabelecer tuneis SOCKS5 via TCP raw:

```powershell
node client-socks.js
```

Testes executados:
- BENIGNO: HTTPS direto sem SOCKS (controle - deve ser permitido)
- SOCKS5-1: handshake SOCKS5 em proxy porta 1080 (deve ser bloqueado)
- SOCKS5-2: handshake SOCKS5 em proxy porta 4145 (deve ser bloqueado)
- SOCKS-TOR: conexao SOCKS5 porta Tor 9050 (deve ser bloqueado)
- SOCKS5-MAL: tunel SOCKS5 para dominio malicioso (deve ser bloqueado)

O script implementa o handshake SOCKS5 (RFC 1928) manualmente, enviando
os bytes de greeting (0x05 0x01 0x00) e CONNECT request via socket TCP.
O Secure Access deve detectar o protocolo e bloquear a conexao.

Nao precisa de dependencias extras (usa modulo `net` nativo do Node.js).

## Roteiro de Evidencias

- WebSocket: `ROTEIRO-EVIDENCIAS.md`
- SOCKS: `ROTEIRO-EVIDENCIAS-SOCKS.md`

Preencha durante a execucao e anexe prints dos logs do Secure Access.

## Observacoes de Seguranca

- Nenhum malware real e usado. Os dominios sao de teste da Cisco e da EICAR.
- O arquivo EICAR e um padrao da industria para testar antivirus, NAO e malware.
- Os IPs de proxy SOCKS usados sao publicos e podem estar offline; o importante
  e que o Secure Access detecte a tentativa de handshake SOCKS no trafego.
- Os testes podem ser executados com seguranca em ambiente corporativo.
