# Roteiro de Evidencias - POC Cisco Secure Access (WebSocket + Antimalware)

## Requisito
> Demonstre o comportamento da solucao ao analisar um link malicioso utilizando
> WebSocket, evidenciando se o trafego e inspecionado, identificado e tratado
> corretamente.

## Dados da Execucao

| Campo                  | Valor                              |
|------------------------|------------------------------------|
| Data/Hora              | ____/____/2026 ___:___             |
| Maquina de teste       | __________________________________ |
| IP da maquina          | __________________________________ |
| Agente Secure Access   | Versao: __________________________ |
| Politica aplicada      | __________________________________ |
| Executor               | __________________________________ |

---

## Matriz de Testes

### Teste 1 - BENIGNO (WebSocket echo publico)

| Item                         | Valor                              |
|------------------------------|------------------------------------|
| URL testada                  | wss://echo.websocket.org           |
| Resultado esperado           | PERMITIDO                          |
| Resultado obtido             | [ ] PERMITIDO  [ ] BLOQUEADO       |
| Handshake completou?         | [ ] Sim  [ ] Nao                   |
| Mensagem recebida?           | [ ] Sim  [ ] Nao                   |
| Evento no Secure Access?     | [ ] Sim (allow)  [ ] Nao           |
| Print do cliente             | (anexar)                           |
| Print do log Secure Access   | (anexar)                           |
| Observacoes                  |                                    |

### Teste 2 - MALICIOSO-1 (examplemalwaredomain.com via WebSocket)

| Item                         | Valor                              |
|------------------------------|------------------------------------|
| URL testada                  | wss://examplemalwaredomain.com/ws  |
| Resultado esperado           | BLOQUEIO                           |
| Resultado obtido             | [ ] PERMITIDO  [ ] BLOQUEADO       |
| Handshake completou?         | [ ] Sim  [ ] Nao                   |
| Tipo de bloqueio             | [ ] DNS  [ ] HTTP block page  [ ] Reset/Drop  [ ] Timeout |
| Evento no Secure Access?     | [ ] Sim (block)  [ ] Nao           |
| Categoria identificada       | __________________________________ |
| Acao aplicada                | __________________________________ |
| Print do cliente             | (anexar)                           |
| Print do log Secure Access   | (anexar)                           |
| Observacoes                  |                                    |

### Teste 3 - MALICIOSO-2 (internetbadguys.com via WebSocket)

| Item                         | Valor                              |
|------------------------------|------------------------------------|
| URL testada                  | wss://internetbadguys.com/ws       |
| Resultado esperado           | BLOQUEIO                           |
| Resultado obtido             | [ ] PERMITIDO  [ ] BLOQUEADO       |
| Handshake completou?         | [ ] Sim  [ ] Nao                   |
| Tipo de bloqueio             | [ ] DNS  [ ] HTTP block page  [ ] Reset/Drop  [ ] Timeout |
| Evento no Secure Access?     | [ ] Sim (block)  [ ] Nao           |
| Categoria identificada       | __________________________________ |
| Acao aplicada                | __________________________________ |
| Print do cliente             | (anexar)                           |
| Print do log Secure Access   | (anexar)                           |
| Observacoes                  |                                    |

### Teste 4 - MALICIOSO-3 (download EICAR - teste antimalware/sandbox)

| Item                         | Valor                              |
|------------------------------|------------------------------------|
| URL testada                  | https://secure.eicar.org/eicar.com.txt |
| Resultado esperado           | BLOQUEIO                           |
| Resultado obtido             | [ ] PERMITIDO  [ ] BLOQUEADO       |
| Download completou?          | [ ] Sim  [ ] Nao                   |
| Tipo de bloqueio             | [ ] Antimalware  [ ] Sandbox  [ ] SWG block page  [ ] Reset |
| Evento no Secure Access?     | [ ] Sim (block)  [ ] Nao           |
| Categoria identificada       | __________________________________ |
| Acao aplicada                | __________________________________ |
| Print do cliente             | (anexar)                           |
| Print do log Secure Access   | (anexar)                           |
| Observacoes                  |                                    |

---

## Resumo de Resultados

| Teste        | Esperado   | Obtido     | Conforme? |
|--------------|------------|------------|-----------|
| BENIGNO      | PERMITIDO  |            | [ ] Sim [ ] Nao |
| MALICIOSO-1  | BLOQUEIO   |            | [ ] Sim [ ] Nao |
| MALICIOSO-2  | BLOQUEIO   |            | [ ] Sim [ ] Nao |
| MALICIOSO-3  | BLOQUEIO   |            | [ ] Sim [ ] Nao |

---

## Criterios de Aceite

O requisito e considerado **ATENDIDO** quando:

1. [  ] Trafego WebSocket benigno e PERMITIDO normalmente
2. [  ] Trafego WebSocket para dominio malicioso e BLOQUEADO (DNS ou SWG)
3. [  ] Evento de seguranca aparece nos logs do Cisco Secure Access com:
   - Identificacao do usuario/dispositivo
   - Dominio/URL de destino
   - Classificacao de risco (malware, phishing, C2, etc.)
   - Acao aplicada (block, deny, terminate)
4. [  ] Download de malware de teste (EICAR) e BLOQUEADO pelo antimalware/sandbox

**Veredicto final:** [ ] ATENDIDO  [ ] NAO ATENDIDO  [ ] PARCIAL

---

## Evidencias Anexas

| # | Descricao                        | Arquivo/Print |
|---|----------------------------------|---------------|
| 1 | Saida do cliente (terminal)      |               |
| 2 | Saida do browser (teste HTML)    |               |
| 3 | Log Secure Access - teste benigno|               |
| 4 | Log Secure Access - bloqueio DNS |               |
| 5 | Log Secure Access - bloqueio SWG |               |
| 6 | Log Secure Access - antimalware  |               |
| 7 | Block page (se exibida)          |               |

---

## Observacoes Gerais

(espaco para anotacoes do executor)
