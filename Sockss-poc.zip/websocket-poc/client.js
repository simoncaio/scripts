const WebSocket = require("ws");

const MODE = process.argv[2] || "benigno";
const TARGET = process.argv[3] || "ws://localhost:8080/feed";
const TIMEOUT_MS = Number(process.env.TIMEOUT_MS || 12000);

const payloads = {
  benigno: JSON.stringify({
    scenario: "benigno",
    action: "heartbeat",
    content: "mensagem de rotina",
    ts: new Date().toISOString()
  }),
  suspeito: JSON.stringify({
    scenario: "suspeito",
    action: "download",
    ioc: "hxxp://bad-example.local/payload.exe",
    note: "simulacao de IOC para POC",
    ts: new Date().toISOString()
  }),
  malicioso: JSON.stringify({
    scenario: "malicioso",
    action: "command-and-control",
    c2: "wss://c2-lab.bad.local/socket",
    fileSample:
      "X5O!P%@AP[4\\PZX54(P^)7CC)7}$EICAR-STANDARD-ANTIVIRUS-TEST-FILE!$H+H*",
    ts: new Date().toISOString()
  })
};

if (!payloads[MODE]) {
  console.error(`[client] modo invalido: ${MODE}`);
  console.error("[client] use: benigno | suspeito | malicioso");
  process.exit(1);
}

console.log(`[client] iniciando teste mode=${MODE} target=${TARGET}`);

const ws = new WebSocket(TARGET, {
  handshakeTimeout: TIMEOUT_MS
});

let finished = false;
const startedAt = Date.now();

const finalize = (exitCode, reason) => {
  if (finished) {
    return;
  }
  finished = true;
  const elapsed = Date.now() - startedAt;
  console.log(`[client] finalizado (${reason}) em ${elapsed}ms`);
  process.exit(exitCode);
};

const timer = setTimeout(() => {
  console.error(`[client] timeout de ${TIMEOUT_MS}ms aguardando resposta`);
  try {
    ws.close(4000, "timeout");
  } catch (_err) {
    // ignora erros de fechamento em timeout
  }
  finalize(2, "timeout");
}, TIMEOUT_MS + 1000);

ws.on("open", () => {
  console.log("[client] conexao aberta, enviando payload...");
  ws.send(payloads[MODE]);
});

ws.on("message", (raw) => {
  console.log(`[client] resposta recebida: ${raw.toString()}`);
  clearTimeout(timer);
  ws.close(1000, "fim-do-teste");
  finalize(0, "sucesso");
});

ws.on("error", (err) => {
  clearTimeout(timer);
  console.error(`[client] erro de conexao/inspecao: ${err.message}`);
  finalize(3, "erro");
});

ws.on("close", (code, reasonBuffer) => {
  const reason = reasonBuffer.toString() || "sem motivo";
  console.log(`[client] socket fechado code=${code} reason="${reason}"`);
});
