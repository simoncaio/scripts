# POC Cisco Secure Access - MSI Malicioso (Antimalware/Sandbox)

## Objetivo
Demonstrar a deteccao e bloqueio de um arquivo .msi malicioso pelo
Cisco Secure Access, incluindo evidencias de log e classificacao da ameaca.

## Estrutura

```
msi-poc/
├── build-msi.ps1               # Gera o arquivo .msi de teste
├── run-test.bat                 # Executa o MSI gerado
├── ROTEIRO-EVIDENCIAS-MSI.md   # Formulario de evidencias
└── README.md
```

## Pre-requisitos

- Windows 10/11 (Windows Installer COM ja esta disponivel)
- PowerShell (para rodar o build)
- curl.exe (nativo no Windows 10 1803+)
- Maquina com agente Cisco Secure Access ativo

## Passo a Passo

### 1. Gerar o MSI

```powershell
Set-ExecutionPolicy -Scope Process -ExecutionPolicy Bypass
.\build-msi.ps1
```

Isso cria o arquivo `poc-malicious-test.msi` na mesma pasta.

### 2. Executar o MSI

Opcao A (batch):
```
.\run-test.bat
```

Opcao B (manual):
```
msiexec /i poc-malicious-test.msi /qb
```

### 3. Observar

Uma janela do cmd.exe abre e tenta:
1. Acessar http://examplemalwaredomain.com/test
2. Acessar http://internetbadguys.com/malware.exe
3. Baixar https://secure.eicar.org/eicar.com.txt

O Cisco Secure Access deve bloquear todas essas chamadas.

### 4. Coletar evidencias

- Print da janela cmd.exe (mostrando bloqueio/erro nas chamadas)
- Logs do Cisco Secure Access (Activity Search / Reports)

## Como Funciona

O script `build-msi.ps1` usa a API COM nativa do Windows Installer
para criar um MSI valido contendo uma Custom Action (Tipo 114) que
executa cmd.exe com comandos curl para URLs maliciosas.

Nao instala nenhum arquivo no sistema. O MSI serve apenas como
veiculo para disparar as chamadas de rede que serao inspecionadas
pelo Secure Access.

## Seguranca

- Os dominios usados (examplemalwaredomain.com, internetbadguys.com)
  sao dominios oficiais de teste da Cisco
- O arquivo EICAR e padrao da industria para testar antivirus
- Nenhum malware real e usado
- O MSI nao instala arquivos nem altera o sistema
