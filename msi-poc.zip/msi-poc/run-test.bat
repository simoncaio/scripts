@echo off
echo.
echo ============================================================
echo   POC Cisco Secure Access - Executando MSI de Teste
echo ============================================================
echo.
echo O MSI vai tentar acessar URLs maliciosas.
echo O Cisco Secure Access deve detectar e bloquear.
echo.
echo Pressione qualquer tecla para iniciar...
pause >nul
echo.
echo Executando: msiexec /i poc-malicious-test.msi /qb
echo.
msiexec /i "%~dp0poc-malicious-test.msi" /qb
echo.
echo ============================================================
echo   Teste finalizado.
echo   Verifique os logs do Cisco Secure Access.
echo ============================================================
echo.
pause
