# Roteiro de Evidencias - POC Cisco Secure Access (MSI Malicioso)

## Requisito
> Demonstre a analise, deteccao e o bloqueio (ou acao configurada) da execucao
> de um arquivo .msi malicioso, incluindo evidencias de log e classificacao da ameaca.

## Dados da Execucao

| Campo                  | Valor                              |
|------------------------|------------------------------------|
| Data/Hora              | ____/____/2026 ___:___             |
| Maquina de teste       | __________________________________ |
| IP da maquina          | __________________________________ |
| Agente Secure Access   | Versao: __________________________ |
| Politica aplicada      | __________________________________ |
| Executor               | __________________________________ |

---

## Descricao do Teste

Foi gerado um arquivo .msi de teste utilizando a API COM nativa do Windows
Installer. O MSI contem uma Custom Action (Tipo 114 - EXE via property com
continue-on-error) que, ao ser executado, realiza chamadas HTTP/HTTPS para
dominios classificados como maliciosos pela Cisco (examplemalwaredomain.com e
internetbadguys.com) e tenta baixar o arquivo de teste EICAR, padrao da
industria para validacao de antimalware. O objetivo e verificar se o Cisco
Secure Access detecta e bloqueia as chamadas originadas pela execucao do MSI,
registrando nos logs a classificacao da ameaca e a acao aplicada.

---

## Matriz de Testes

### Teste 1 - Chamada HTTP para examplemalwaredomain.com

| Item                         | Valor                              |
|------------------------------|------------------------------------|
| URL chamada pelo MSI         | http://examplemalwaredomain.com/test |
| Metodo                       | curl.exe via Custom Action do MSI  |
| Resultado esperado           | BLOQUEIO                           |
| Resultado obtido             | [ ] BLOQUEADO  [ ] PERMITIDO       |
| Tipo de bloqueio             | [ ] DNS  [ ] SWG/Proxy  [ ] Antimalware  [ ] Reset/Drop |
| Evento no Secure Access?     | [ ] Sim (block)  [ ] Nao           |
| Categoria identificada       | __________________________________ |
| Acao aplicada                | __________________________________ |
| Print do terminal (curl)     | (anexar)                           |
| Print do log Secure Access   | (anexar)                           |
| Observacoes                  |                                    |

### Teste 2 - Chamada HTTP para internetbadguys.com

| Item                         | Valor                              |
|------------------------------|------------------------------------|
| URL chamada pelo MSI         | http://internetbadguys.com/malware.exe |
| Metodo                       | curl.exe via Custom Action do MSI  |
| Resultado esperado           | BLOQUEIO                           |
| Resultado obtido             | [ ] BLOQUEADO  [ ] PERMITIDO       |
| Tipo de bloqueio             | [ ] DNS  [ ] SWG/Proxy  [ ] Antimalware  [ ] Reset/Drop |
| Evento no Secure Access?     | [ ] Sim (block)  [ ] Nao           |
| Categoria identificada       | __________________________________ |
| Acao aplicada                | __________________________________ |
| Print do terminal (curl)     | (anexar)                           |
| Print do log Secure Access   | (anexar)                           |
| Observacoes                  |                                    |

### Teste 3 - Download EICAR (antimalware/sandbox)

| Item                         | Valor                              |
|------------------------------|------------------------------------|
| URL chamada pelo MSI         | https://secure.eicar.org/eicar.com.txt |
| Metodo                       | curl.exe via Custom Action do MSI  |
| Resultado esperado           | BLOQUEIO                           |
| Resultado obtido             | [ ] BLOQUEADO  [ ] PERMITIDO       |
| Tipo de bloqueio             | [ ] Antimalware  [ ] Sandbox  [ ] SWG  [ ] DNS |
| Arquivo EICAR salvo?         | [ ] Sim  [ ] Nao (bloqueado)       |
| Evento no Secure Access?     | [ ] Sim (block)  [ ] Nao           |
| Categoria identificada       | __________________________________ |
| Acao aplicada                | __________________________________ |
| Print do terminal (curl)     | (anexar)                           |
| Print do log Secure Access   | (anexar)                           |
| Observacoes                  |                                    |

### Teste 4 - Deteccao do proprio arquivo MSI (analise estatica)

| Item                         | Valor                              |
|------------------------------|------------------------------------|
| Arquivo                      | poc-malicious-test.msi             |
| Resultado esperado           | DETECCAO (opcional)                |
| O Secure Access detectou o MSI antes da execucao? | [ ] Sim  [ ] Nao |
| Classificacao                | __________________________________ |
| Acao aplicada                | __________________________________ |
| Print do log Secure Access   | (anexar)                           |
| Observacoes                  | Nem toda solucao detecta na analise estatica; o principal e o bloqueio das chamadas |

---

## Resumo de Resultados

| Teste              | Esperado   | Obtido     | Conforme? |
|--------------------|------------|------------|-----------|
| examplemalwaredomain.com | BLOQUEIO |       | [ ] Sim [ ] Nao |
| internetbadguys.com      | BLOQUEIO |       | [ ] Sim [ ] Nao |
| EICAR download           | BLOQUEIO |       | [ ] Sim [ ] Nao |
| Deteccao estatica MSI    | OPCIONAL |       | [ ] Sim [ ] Nao [ ] N/A |

---

## Criterios de Aceite

O requisito e considerado **ATENDIDO** quando:

1. [  ] O MSI executa e tenta chamar URLs maliciosas
2. [  ] O Cisco Secure Access BLOQUEIA pelo menos as chamadas a dominios maliciosos
3. [  ] Logs do Secure Access registram os eventos com:
   - Identificacao do usuario/dispositivo
   - URL/dominio de destino
   - Classificacao da ameaca (malware, phishing, etc.)
   - Acao aplicada (block/deny)
4. [  ] O download do arquivo EICAR e bloqueado (antimalware/sandbox)
5. [  ] (Opcional) O arquivo MSI e detectado como suspeito antes da execucao

**Veredicto final:** [ ] ATENDIDO  [ ] NAO ATENDIDO  [ ] PARCIAL

---

## Evidencias Anexas

| # | Descricao                                   | Arquivo/Print |
|---|---------------------------------------------|---------------|
| 1 | Tela do build-msi.ps1 (geracao do MSI)      |               |
| 2 | Tela do cmd.exe durante execucao do MSI      |               |
| 3 | Log Secure Access - bloqueio dominio malware |               |
| 4 | Log Secure Access - bloqueio EICAR           |               |
| 5 | Log Secure Access - deteccao estatica MSI    |               |

---

## Observacoes Gerais

(espaco para anotacoes do executor)
